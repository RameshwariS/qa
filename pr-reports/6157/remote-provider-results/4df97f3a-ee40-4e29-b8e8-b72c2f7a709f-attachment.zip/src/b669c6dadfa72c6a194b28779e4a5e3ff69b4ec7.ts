/**
 * End-to-end coverage of the Import Design modal on `/catalog/content/my-designs`.
 *
 * This is the product surface behind the design-import form contract. The modal
 * is rendered from the canonical `DesignImportRjsfSchemaV1Beta3`, and
 * `GenericRJSFModal` hands `handleImportDesign` the raw RJSF formData with no
 * remapping — so the field names the handler destructures (`uploadType`,
 * `name`, `url`, `file`) are joined to the schema only by string keys. The unit
 * guards pin that join statically:
 *
 *   - `__tests__/components/catalog/design-import-contract.test.ts` (runtime)
 *   - `__tests__/typetests/design-import-contract.typetest.ts` (tsc)
 *
 * This spec closes the loop at the level a user experiences: it opens the real
 * modal, drives BOTH uploadType branches, and asserts the exact body that
 * reaches `POST /api/content/patterns` — which is what would silently become
 * `{save: true, patternData: {name: undefined}}` if the formData shape ever
 * drifted from the schema (the failure mode #5863 describes for filters).
 */

import { expect, test } from "@playwright/test";
import path from "node:path";
import {
  createAuthenticatedShellHandlers,
  createDesignsHandlers,
  createFallbackHandlers,
  createPermissionKeysHandler,
  createSharedShellHandlers,
  mockApi
} from "./helpers/network";

const MY_DESIGNS_URL = "/catalog/content/my-designs";

/**
 * Where the reviewer-facing screenshots land. Defaults inside `test-results/`
 * (gitignored, cleaned with the rest of the run); override with
 * `DESIGN_IMPORT_EVIDENCE_DIR` to collect them somewhere durable.
 */
const EVIDENCE_DIR =
  process.env.DESIGN_IMPORT_EVIDENCE_DIR ??
  path.resolve(__dirname, "..", "test-results", "design-import-evidence");

const shot = (name: string) => path.join(EVIDENCE_DIR, `${name}.png`);

const authenticatedUser = {
  id: "user-1",
  first_name: "Test",
  last_name: "User",
  email: "test@example.com",
  preferences: { selectedOrg: "org-1" }
};

const organization = {
  id: "org-1",
  name: "Test Organization",
  domain: "localhost:3000"
};

const DESIGN_YAML = "apiVersion: v1\nkind: Namespace\nmetadata:\n  name: import-demo\n";

/**
 * Boots the My Designs page with an empty design list and the one permission
 * key the page gates on, and returns the array the upsert bodies land in.
 */
async function openMyDesigns(page: import("@playwright/test").Page) {
  const upsertBodies: Array<Record<string, unknown>> = [];

  await mockApi(page, [
    ...createSharedShellHandlers({
      user: authenticatedUser,
      organizations: [organization]
    }),
    ...createPermissionKeysHandler(["VIEW_CATALOG", "VIEW_DESIGNS"]),
    ...createAuthenticatedShellHandlers({ orgId: "org-1", skipKeys: true }),
    // Records the design-import request body, then falls through (returns
    // undefined) so `createDesignsHandlers` below still answers it.
    request => {
      if (
        request.method() === "POST" &&
        new URL(request.url()).pathname === "/api/content/patterns"
      ) {
        upsertBodies.push(JSON.parse(request.postData() ?? "{}"));
      }
      return undefined;
    },
    ...createDesignsHandlers({ patterns: [] }),
    ...createFallbackHandlers()
  ]);

  await page.goto(MY_DESIGNS_URL, { waitUntil: "domcontentloaded" });
  await expect(page.getByRole("button", { name: "Import" })).toBeVisible();

  return upsertBodies;
}

/** The design-name field itself, never its information affordance. */
const designFileName = (modal: import("@playwright/test").Locator) =>
  modal.getByRole("textbox", { name: "Design file name", exact: true });

/** Opens the Import Design modal and waits for the RJSF chunk to render. */
async function openImportModal(page: import("@playwright/test").Page) {
  await page.getByRole("button", { name: "Import" }).click();
  const modal = page.getByRole("dialog").filter({ hasText: "Import Design" });
  await expect(modal).toBeVisible();
  // The RJSF form is code-split (`dynamic(() => import("../rjsf"))`); wait for
  // a real field rather than the spinner.
  //
  // By ROLE, not `getByLabel`: every RJSF field now carries an information
  // affordance whose accessible name is `<label>: <description>`, and
  // `getByLabel` matches a name by SUBSTRING - so a bare `getByLabel("Design
  // file name")` resolves to the input AND its help button (strict mode
  // violation). The button is a `button`; the field is a `textbox`.
  await expect(designFileName(modal)).toBeVisible();
  return modal;
}

test.describe("import design — canonical form contract at the product surface", () => {
  test("URL Import branch posts { save, url, patternData.name }", async ({ page }) => {
    const upsertBodies = await openMyDesigns(page);
    const modal = await openImportModal(page);

    // `uploadType` defaults to "URL Import" in the canonical schema, so the URL
    // branch is what a user sees first.
    await expect(modal.getByRole("radio", { name: "URL Import" })).toBeChecked();
    await expect(modal.getByRole("textbox", { name: "URL", exact: true })).toBeVisible();
    await modal.screenshot({ path: shot("import-modal-url-branch") });

    await designFileName(modal).fill("Imported From URL");
    await modal
      .getByRole("textbox", { name: "URL", exact: true })
      .fill("https://raw.githubusercontent.com/example/design.yaml");

    await modal.screenshot({ path: shot("import-modal-url-branch-filled") });

    await modal.getByRole("button", { name: "Import", exact: true }).click();

    await expect.poll(() => upsertBodies.length).toBe(1);
    expect(upsertBodies[0]).toEqual({
      save: true,
      url: "https://raw.githubusercontent.com/example/design.yaml",
      patternData: { name: "Imported From URL" }
    });

    // The user-visible outcome: success toast, and the imported design now in
    // the list — which only happens if `patternData.name` actually carried a
    // value through the form -> handler -> request-body chain.
    await expect(page.getByText("Design imported")).toBeVisible();
    await expect(page.getByText("Imported From URL").first()).toBeVisible();
    await page.screenshot({ path: shot("import-url-success-toast") });
  });

  test("File Upload branch posts { save, patternData.name, patternData.patternFile } with the data-url prefix stripped", async ({
    page
  }) => {
    const upsertBodies = await openMyDesigns(page);
    const modal = await openImportModal(page);

    // Switching the discriminator swaps the conditional branch: the URL text
    // field is replaced by the RJSF FileWidget.
    await modal.getByRole("radio", { name: "File Upload" }).check();
    await expect(modal.getByRole("textbox", { name: "URL", exact: true })).toHaveCount(0);

    const fileInput = modal.locator('input[type="file"]');
    await expect(fileInput).toBeAttached();
    await modal.screenshot({ path: shot("import-modal-file-branch") });

    await designFileName(modal).fill("Imported From File");
    await fileInput.setInputFiles({
      name: "namespace.yaml",
      mimeType: "application/x-yaml",
      buffer: Buffer.from(DESIGN_YAML, "utf8")
    });

    await modal.screenshot({ path: shot("import-modal-file-branch-filled") });

    await modal.getByRole("button", { name: "Import", exact: true }).click();

    await expect.poll(() => upsertBodies.length).toBe(1);
    // `patternFile` is the DECODED file, proving `getDecodedFile` stripped the
    // `data:<mime>;base64,` prefix the RJSF `format: data-url` widget emits.
    expect(upsertBodies[0]).toEqual({
      save: true,
      patternData: {
        name: "Imported From File",
        patternFile: DESIGN_YAML
      }
    });

    await expect(page.getByText("Design imported")).toBeVisible();
    await expect(page.getByText("Imported From File").first()).toBeVisible();
    await page.screenshot({ path: shot("import-file-success-toast") });
  });
});
