import { Keys } from "@meshery/schemas/permissions";
import { expect, test } from "@playwright/test";
import {
  createAuthenticatedShellHandlers,
  createConnectionsHandlers,
  createFallbackHandlers,
  createGithubWizardHandlers,
  createSharedShellHandlers,
  githubConnectionFixture,
  mockApi
} from "./helpers/network";

/**
 * TP-017 - GitHub connection wizard.
 *
 * `connections.spec.ts` covers only the static integrations catalogue and
 * explicitly defers the wizard itself ("intentionally validated only in the
 * post-deployment smoke test suite"), which in practice meant the wizard had no
 * browser coverage at all. These specs close that gap against the mocked API,
 * so the routing, stepper navigation, metadata reads and failure paths are
 * exercised without needing a live GitHub App round-trip.
 *
 * What is deliberately NOT covered here: the leg that leaves the app for
 * github.com (the "Connect" button) and the real webhook delivery. Those cross
 * an origin the test cannot follow. The button's *target* is asserted instead -
 * see the GITHUB_APP_URL case, which is a regression guard for the local build
 * pointing at the production GitHub App.
 */

const viewConnectionsKey = {
  id: Keys.WorkspaceManagementViewConnections.id,
  function: Keys.WorkspaceManagementViewConnections.function
};

const authenticatedUser = {
  id: "user-1",
  first_name: "Test",
  last_name: "User",
  email: "test@example.com",
  preferences: { selectedOrg: "org-1" }
};

// The authenticated shell bounces to /auth/switch-domain unless the active
// org's `domain` is byte-identical to the host the browser is on, so derive it
// from the configured base URL instead of hardcoding a port.
const organization = {
  id: "org-1",
  name: "Test Organization",
  domain: new URL(process.env.PLAYWRIGHT_BASE_URL || "http://localhost:3000").host
};

/**
 * The wizard is rendered inside the authenticated AppShell, which supplies the
 * `profileData` prop the route orchestration reads for the fallback URL id.
 * Every spec needs that shell, so build it once.
 *
 * Ordering matters: `createAuthenticatedShellHandlers` answers
 * `GET /api/integrations/connections` with a hardcoded empty list for the navbar
 * connection badges. It must come AFTER `createConnectionsHandlers`, or it
 * shadows the fixture and the wizard can never see an existing GitHub
 * connection - which silently turns every "already connected" case into a
 * "first install" case.
 */
const shellHandlers = (connections: Array<Record<string, unknown>>) => [
  ...createSharedShellHandlers({
    user: authenticatedUser,
    organizations: [organization]
  }),
  ...createConnectionsHandlers({ connections }),
  ...createAuthenticatedShellHandlers({
    orgId: "org-1",
    keys: [viewConnectionsKey]
  }),
  ...createFallbackHandlers()
];

/**
 * `npm run dev` starts the UI with an empty STRIPE_PUBLIC_KEY, so Stripe.js
 * logs one unconditional error on every authenticated page. It is environmental
 * and unrelated to the wizard; filter it so these specs fail only on errors the
 * wizard itself raises.
 */
const STRIPE_DEV_NOISE = /Please call Stripe\(\) with your publishable key/;
const wizardPageErrors = (errors: string[]) =>
  errors.filter(message => !STRIPE_DEV_NOISE.test(message));

test.describe("GitHub connection wizard - entry", () => {
  test("TC-017-001 direct URL /connect/github/new renders step 1 with the Connect action", async ({
    page
  }) => {
    await mockApi(page, [...createGithubWizardHandlers(), ...shellHandlers([])]);

    await page.goto("/connect/github/new");

    // The stepper rail lists all seven steps; step 1 is the GitHub App connect.
    await expect(page.getByText("Connect GitHub App").first()).toBeVisible();
    await expect(page.getByRole("button", { name: /^Connect$/ }).first()).toBeVisible();
  });

  test("TC-017-002 wizard shows every stepper stage, not just the active one", async ({
    page
  }) => {
    await mockApi(page, [...createGithubWizardHandlers(), ...shellHandlers([])]);

    await page.goto("/connect/github/new");

    for (const label of [
      "Connect GitHub App",
      "Select Repositories",
      "Import Designs",
      "Finish"
    ]) {
      await expect(page.getByText(label).first()).toBeVisible();
    }
    // "Enable Snapshots" labels three consecutive steps, distinguished by their
    // secondary line.
    await expect(page.getByText("(Configure Secrets)").first()).toBeVisible();
  });

  test("TC-017-003 the Connect button targets a GitHub App install URL for THIS environment", async ({
    page
  }) => {
    // `window.open(GITHUB_APP_URL, "_self")` is the handoff. Stub it before any
    // app code runs and record the target rather than following it - github.com
    // is out of the test's reach.
    await page.addInitScript(() => {
      (window as unknown as { __openedUrls: string[] }).__openedUrls = [];
      window.open = ((url?: string | URL) => {
        (window as unknown as { __openedUrls: string[] }).__openedUrls.push(
          String(url ?? "")
        );
        return null;
      }) as typeof window.open;
    });

    await mockApi(page, [...createGithubWizardHandlers(), ...shellHandlers([])]);

    await page.goto("/connect/github/new");

    await page
      .getByRole("button", { name: /^Connect$/ })
      .first()
      .click();

    await expect
      .poll(() =>
        page.evaluate(
          () => (window as unknown as { __openedUrls: string[] }).__openedUrls
        )
      )
      .toHaveLength(1);

    const [opened] = await page.evaluate(
      () => (window as unknown as { __openedUrls: string[] }).__openedUrls
    );

    expect(opened).toMatch(/^https:\/\/github\.com\/apps\/[a-z-]+\/installations\/new$/);

    // The dev server runs with NODE_ENV=development, so this must be the
    // meshery-dev app - NOT the production `meshery` app. `make ui-build`
    // builds with NODE_ENV=production (deliberately, commit 2c46dec1efe) and
    // used to bake the production app URL into a local build, which makes the
    // installation handoff unreturnable locally: the production app's callback
    // points at cloud.layer5.io. The app URL now keys off the deployment
    // target, not the build mode.
    expect(opened).not.toContain("/apps/meshery/installations/new");
  });
});

test.describe("GitHub connection wizard - installation return leg", () => {
  test("TC-017-004 returning with githubLogin=true advances past step 1 to repository selection", async ({
    page
  }) => {
    await mockApi(page, [
      ...createGithubWizardHandlers({
        repositories: [
          { name: "sample-repo", owner: { login: "octo-org" } },
          { name: "other-repo", owner: { login: "octo-org" } }
        ]
      }),
      ...shellHandlers([githubConnectionFixture()])
    ]);

    await page.goto("/connect/github/reconfigure/gh-conn-1?githubLogin=true&id=9911");

    await expect(
      page.getByLabel("Select a repository", { exact: true }).first()
    ).toBeVisible();
  });

  test("TC-017-005 repository list is fetched with the installation id from the URL", async ({
    page
  }) => {
    const seen: string[] = [];
    page.on("request", req => {
      const u = new URL(req.url());
      if (u.pathname === "/api/integrations/github") {
        seen.push(u.searchParams.get("id") ?? "");
      }
    });

    await mockApi(page, [
      ...createGithubWizardHandlers(),
      ...shellHandlers([githubConnectionFixture()])
    ]);

    await page.goto("/connect/github/reconfigure/gh-conn-1?githubLogin=true&id=9911");
    await expect(
      page.getByLabel("Select a repository", { exact: true }).first()
    ).toBeVisible();

    expect(seen.length).toBeGreaterThan(0);
    expect(seen.every(id => id === "9911")).toBe(true);
  });

  test("TC-017-006 a single available repository is auto-selected", async ({ page }) => {
    await mockApi(page, [
      ...createGithubWizardHandlers({
        repositories: [{ name: "only-repo", owner: { login: "octo-org" } }]
      }),
      ...shellHandlers([githubConnectionFixture()])
    ]);

    await page.goto("/connect/github/reconfigure/gh-conn-1?githubLogin=true&id=9911");

    await expect(page.getByText("octo-org/only-repo").first()).toBeVisible();
  });
});

test.describe("GitHub connection wizard - metadata shape compatibility", () => {
  /**
   * The `installationId` / `installation_id` fallback exists because the wire
   * shape changed once. `readGithubMetadata` has unit coverage; these two cases
   * prove the fallback actually reaches the browser - the redirect that carries
   * the installation id into the stepper is built from it in
   * `components/connect/index.tsx`.
   */
  for (const shape of ["camel", "snake"] as const) {
    test(`TC-017-007-${shape} /connect/github/new on an existing connection carries the installation id into the reconfigure URL (${shape}Case metadata)`, async ({
      page
    }) => {
      await mockApi(page, [
        ...createGithubWizardHandlers(),
        ...shellHandlers([
          githubConnectionFixture({ metadataShape: shape, installationId: "5150" })
        ])
      ]);

      await page.goto("/connect/github/new");

      // The wizard detects the existing connection and re-routes to the
      // reconfigure leg, carrying the installation id read out of metadata.
      await page.waitForURL(/\/connect\/github\/reconfigure\//, { timeout: 15_000 });
      expect(page.url()).toContain("id=5150");
      expect(page.url()).toContain("githubLogin=true");
    });
  }
});

test.describe("GitHub connection wizard - failure paths", () => {
  test("TC-017-008 verify leg with a revoked installation (status 404) does not silently land on a blank page", async ({
    page
  }) => {
    await mockApi(page, [
      ...createGithubWizardHandlers({ statusCode: 404 }),
      ...shellHandlers([])
    ]);

    await page.goto("/connect/github/verify?githubLogin=true&id=9911");

    // The verify screen must keep telling the user what it is doing rather than
    // rendering nothing at all. A 404 means the app installation is gone; the
    // user must not be stranded on an empty document.
    await expect(page.getByText(/Verifying your Github Installation/i)).toBeVisible();
  });

  test("TC-017-009 return leg with NO installation id still renders the wizard rather than crashing", async ({
    page
  }) => {
    const pageErrors: string[] = [];
    page.on("pageerror", e => pageErrors.push(e.message));

    await mockApi(page, [
      ...createGithubWizardHandlers(),
      ...shellHandlers([githubConnectionFixture()])
    ]);

    // GitHub can bounce the user back without an installation_id when the
    // install is abandoned on the account-picker screen.
    await page.goto("/connect/github/reconfigure/gh-conn-1?githubLogin=true");

    await expect(page.getByText("Select Repositories").first()).toBeVisible();
    expect(wizardPageErrors(pageErrors)).toEqual([]);
  });

  test("TC-017-010 wizard renders with zero accessible repositories (wrong account installed the app)", async ({
    page
  }) => {
    await mockApi(page, [
      ...createGithubWizardHandlers({ repositories: [] }),
      ...shellHandlers([githubConnectionFixture()])
    ]);

    await page.goto("/connect/github/reconfigure/gh-conn-1?githubLogin=true&id=9911");

    // With no repositories the Next control must stay disabled - there is
    // nothing to advance with.
    await expect(
      page.getByLabel("Select a repository", { exact: true }).first()
    ).toBeVisible();
    const next = page.getByRole("button", { name: /^Next$/ }).first();
    await expect(next).toBeDisabled();
  });

  test("TC-017-011 the wizard route emits no uncaught page errors on a cold direct load", async ({
    page
  }) => {
    const pageErrors: string[] = [];
    page.on("pageerror", e => pageErrors.push(e.message));

    await mockApi(page, [...createGithubWizardHandlers(), ...shellHandlers([])]);

    await page.goto("/connect/github/new");
    await expect(page.getByText("Connect GitHub App").first()).toBeVisible();

    expect(wizardPageErrors(pageErrors)).toEqual([]);
  });
});

test.describe("GitHub connection wizard - idempotency", () => {
  test("TC-017-012 running the wizard again for an already-connected account re-enters reconfigure, not a duplicate new connection", async ({
    page
  }) => {
    const connectionPosts: string[] = [];
    page.on("request", req => {
      if (
        req.method() === "POST" &&
        new URL(req.url()).pathname === "/api/integrations/connections"
      ) {
        connectionPosts.push(req.url());
      }
    });

    await mockApi(page, [
      ...createGithubWizardHandlers(),
      ...shellHandlers([githubConnectionFixture()])
    ]);

    await page.goto("/connect/github/new");
    await page.waitForURL(/\/connect\/github\/reconfigure\//, { timeout: 15_000 });

    // Second pass through the same entry point must behave identically.
    await page.goto("/connect/github/new");
    await page.waitForURL(/\/connect\/github\/reconfigure\//, { timeout: 15_000 });

    expect(connectionPosts).toEqual([]);
  });
});
