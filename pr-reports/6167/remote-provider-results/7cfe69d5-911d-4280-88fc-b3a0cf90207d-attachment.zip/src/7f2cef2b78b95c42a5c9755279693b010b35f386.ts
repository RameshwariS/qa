import type { GetUserTokensApiResponse } from "@meshery/schemas/cloudApi";
import { Keys } from "@meshery/schemas/permissions";
import type { Page, Request } from "@playwright/test";

type MockResponse = {
  body: unknown;
  contentType?: string;
  headers?: Record<string, string>;
  status?: number;
};

type ApiHandler = (
  request: Request
) => MockResponse | undefined | Promise<MockResponse | undefined>;

const jsonResponse = (body: unknown, status = 200): MockResponse => ({
  body,
  status,
  contentType: "application/json"
});

const getPathname = (request: Request) => new URL(request.url()).pathname;

/**
 * Extracts the last non-empty path segment from a URL pathname.
 * Filters out empty segments produced by leading/trailing slashes so that
 * `/api/foo/123` and `/api/foo/123/` both yield `123`.
 */
const lastPathSegment = (pathname: string): string | undefined =>
  pathname.split("/").filter(Boolean).pop();

/**
 * Extracts the path segment that immediately precedes the final segment
 * (e.g. `.../{id}/accept` yields `{id}`). Filters empty segments so trailing
 * slashes do not throw off the lookup.
 */
const secondToLastPathSegment = (pathname: string): string | undefined =>
  pathname.split("/").filter(Boolean).slice(-2)[0];

/**
 * Splits a URL pathname on `/` and drops empty segments (produced by
 * leading/trailing slashes). Every path-based matcher in this module reads
 * from this helper so behaviour stays consistent when the client adds or
 * omits a trailing slash.
 */
const pathSegments = (pathname: string): string[] => pathname.split("/").filter(Boolean);

/**
 * True when `pathname` refers to exactly `/api/identity/orgs/:id` — a
 * single-organization fetch — rather than any deeper subpath like
 * `.../users/keys` or `.../roles`. Centralising this check avoids the
 * shared-shell handler accidentally shadowing the deeper endpoints.
 */
const isSingleOrgLookup = (pathname: string): boolean => {
  if (pathname === "/api/identity/orgs/by-domain") return false;
  if (!pathname.startsWith("/api/identity/orgs/")) return false;
  const segments = pathSegments(pathname);
  // ["api", "identity", "orgs", ":id"]
  return segments.length === 4;
};

export async function mockApi(page: Page, handlers: ApiHandler[]) {
  await page.route("**/api/**", async route => {
    const request = route.request();

    for (const handler of handlers) {
      const response = await handler(request);

      if (response) {
        await route.fulfill({
          body:
            response.contentType === "application/json"
              ? JSON.stringify(response.body)
              : String(response.body ?? ""),
          contentType: response.contentType,
          headers: response.headers,
          status: response.status ?? 200
        });
        return;
      }
    }

    throw new Error(`Unhandled API request: ${request.method()} ${request.url()}`);
  });
}

export async function mockLoginPage(page: Page) {
  await page.route("**/login**", async route => {
    await route.fulfill({
      status: 200,
      contentType: "text/html",
      body: "<!doctype html><html><body><main><h1>Login page stub</h1></main></body></html>"
    });
  });
}

export function createSharedShellHandlers(options?: {
  organizations?: Array<Record<string, unknown>>;
  user?: Record<string, unknown>;
}): ApiHandler[] {
  const organizations = options?.organizations ?? [];
  const user = { roleNames: [] as string[], ...(options?.user ?? {}) };

  return [
    request => {
      const pathname = getPathname(request);

      if (pathname === "/api/identity/users/profile") {
        return jsonResponse(user);
      }

      if (pathname === "/api/identity/orgs/by-domain") {
        return jsonResponse(null);
      }

      if (pathname === "/api/identity/orgs") {
        return jsonResponse({ organizations });
      }

      // Match ONLY the single-org fetch (`/api/identity/orgs/:id`) — not
      // any deeper subpath like `/api/identity/orgs/:id/users/keys` or
      // `/api/identity/orgs/:id/roles`. A naive `startsWith` here silently
      // swallows those endpoints and returns the wrong payload, which has
      // caused spurious "not authorized" failures in permission-gated
      // tests when the keys response was replaced with a fake orgs payload.
      if (isSingleOrgLookup(pathname)) {
        const orgId = lastPathSegment(pathname);
        const match = organizations.find(o => o.id === orgId);
        if (match) {
          return jsonResponse({ organizations: [match] });
        }
        return jsonResponse({
          organizations: [
            {
              id: orgId,
              name: "Test Organization",
              domain: "localhost:3000"
            }
          ]
        });
      }

      return undefined;
    }
  ];
}

/**
 * Answers the Instructor Console's summary endpoint, plus the paginated
 * curricula list its datatable reads.
 *
 * Both are needed together: the console's aggregate strip and its datatable
 * have different sources (`/academy/admin/summary` and `/academy/curricula`),
 * and a spec that mocks only one renders half a page. Place this BEFORE
 * `createAcademyListHandlers` or `createFallbackHandlers`, either of which also
 * claims `/api/academy/curricula` - `mockApi` takes the first handler that
 * answers.
 */
export function createAcademyInstructorConsoleHandlers(options: {
  summary: Record<string, unknown>;
  curricula?: Array<Record<string, unknown>>;
}): ApiHandler[] {
  const curricula = options.curricula ?? [];

  return [
    request => {
      const pathname = getPathname(request);

      if (request.method() === "GET" && pathname === "/api/academy/admin/summary") {
        return jsonResponse(options.summary);
      }

      if (request.method() === "GET" && pathname === "/api/academy/curricula") {
        return jsonResponse({ data: curricula, total: curricula.length });
      }

      if (request.method() === "GET" && pathname === "/api/academy/admin/registrations") {
        return jsonResponse({ data: [], totalCount: 0, page: 1, pageSize: 20 });
      }

      return undefined;
    }
  ];
}

export function createAcademyListHandlers(
  items: Array<Record<string, unknown>>
): ApiHandler[] {
  return [
    request => {
      const pathname = getPathname(request);

      if (
        request.method() === "GET" &&
        (pathname === "/api/academy" || pathname === "/api/academy/curricula")
      ) {
        return jsonResponse({ data: items, total: items.length });
      }

      return undefined;
    }
  ];
}

export function createAcademyCertificateNotFoundHandlers(): ApiHandler[] {
  return [
    request => {
      const pathname = getPathname(request);

      if (request.method() === "GET" && pathname.includes("/api/academy/certificates/")) {
        return jsonResponse({ message: "Certificate Not Found." }, 404);
      }

      return undefined;
    }
  ];
}

export function createAcademyLearningPathHandlers(options: {
  content: Record<string, unknown>;
  registration?: Record<string, unknown> | null;
  slug: string;
}): ApiHandler[] {
  return [
    request => {
      const pathname = getPathname(request);

      if (
        request.method() === "GET" &&
        pathname.startsWith("/api/academy/registrations")
      ) {
        return jsonResponse(options.registration ?? null);
      }

      if (
        request.method() === "GET" &&
        pathname.startsWith("/api/academy") &&
        pathname.includes(`/${options.slug}`)
      ) {
        return jsonResponse(options.content);
      }

      return undefined;
    }
  ];
}

/**
 * Handlers for authenticated-shell APIs that many pages rely on during app
 * bootstrap: user keys, roles, org preferences, org activity, and online-users.
 */
export function createAuthenticatedShellHandlers(options?: {
  orgId?: string;
  roles?: Array<Record<string, unknown>>;
  keys?: Array<Record<string, unknown>>;
  preferences?: Record<string, unknown>;
  /**
   * When true, skip the `/users/keys` handler so a preceding
   * `createPermissionKeysHandler` takes effect. Equivalent to placing
   * `createPermissionKeysHandler` before this helper in the chain.
   */
  skipKeys?: boolean;
}): ApiHandler[] {
  const orgId = options?.orgId ?? "org-1";
  const roles = options?.roles ?? [];
  const userKeys = options?.keys ?? [];
  const skipKeys = options?.skipKeys ?? false;
  // `theme.id` is read WITHOUT optional chaining in
  // `components/general/use-sistent/index.js`, so an empty preferences
  // payload crashes the shell with "undefined.id". Default to the shipped
  // default theme id.
  const preferences = {
    theme: { id: "default" },
    ...(options?.preferences ?? {})
  };

  return [
    request => {
      const pathname = getPathname(request);

      // GET /api/identity/orgs/:orgId/users/keys
      if (
        !skipKeys &&
        request.method() === "GET" &&
        pathname === `/api/identity/orgs/${orgId}/users/keys`
      ) {
        return jsonResponse({ keys: userKeys });
      }

      // GET /api/identity/orgs/:orgId/roles
      if (
        request.method() === "GET" &&
        pathname === `/api/identity/orgs/${orgId}/roles`
      ) {
        return jsonResponse({
          roles,
          page: 0,
          pageSize: 10,
          totalCount: roles.length
        });
      }

      // GET /api/identity/orgs/:orgId/preferences
      if (
        request.method() === "GET" &&
        pathname === `/api/identity/orgs/${orgId}/preferences`
      ) {
        return jsonResponse({ preferences });
      }

      // POST /api/identity/orgs/:orgId/activity
      if (
        request.method() === "POST" &&
        pathname.startsWith("/api/identity/orgs/") &&
        pathname.endsWith("/activity")
      ) {
        return jsonResponse({});
      }

      // POST /api/events — used by RegisterOrgActivity on every shell render.
      if (
        request.method() === "POST" &&
        (pathname === "/api/events" ||
          pathname === "/api/events/audit" ||
          pathname === "/api/events/pages")
      ) {
        return jsonResponse({ success: true });
      }

      // GET /api/identity/users/online — RTK Query consumer does
      // `const { data: activeUsers = [] }` and then `.slice(...)`, so the
      // response MUST be an array (even when empty). Returning `{count: 1}`
      // short-circuits the default, which makes the UI blow up with
      // "activeUsers.slice is not a function".
      if (request.method() === "GET" && pathname === "/api/identity/users/online") {
        return jsonResponse([]);
      }

      // PUT /api/identity/users/preferences — preference mutation issued by
      // the app shell. A no-op 200 is enough for render-only specs.
      if (request.method() === "PUT" && pathname === "/api/identity/users/preferences") {
        return jsonResponse({ success: true });
      }

      // GET /api/identity/orgs/:orgId/users/online — per-org active users.
      if (
        request.method() === "GET" &&
        pathname.match(/^\/api\/identity\/orgs\/[^/]+\/users\/online$/)
      ) {
        return jsonResponse([]);
      }

      // GET /api/identity/users/profile/details
      if (
        request.method() === "GET" &&
        pathname === "/api/identity/users/profile/details"
      ) {
        return jsonResponse({});
      }

      // GET /api/identity/users/profile/provider
      if (
        request.method() === "GET" &&
        pathname === "/api/identity/users/profile/provider"
      ) {
        return jsonResponse({ provider: "email" });
      }

      // Catch-all for any unhandled users/keys endpoint pattern
      if (
        request.method() === "GET" &&
        pathname.match(/\/api\/identity\/orgs\/[^/]+\/users\/keys/)
      ) {
        return jsonResponse({ keys: userKeys });
      }

      // Shell bootstrap endpoints that every authenticated page hits.

      // GET /api/system/version — header build info.
      if (request.method() === "GET" && pathname === "/api/system/version") {
        return jsonResponse({
          version: "0.0.0-test",
          commitsha: "0000000"
        });
      }

      // GET /api/capabilities — feature flags / entitlements.
      if (request.method() === "GET" && pathname === "/api/capabilities") {
        return jsonResponse({
          capabilities: [],
          provider: "Meshery",
          provider_url: "/",
          extensions: {}
        });
      }

      // GET /api/integrations/connections — navbar connection badges.
      if (request.method() === "GET" && pathname === "/api/integrations/connections") {
        return jsonResponse({
          connections: [],
          page: 0,
          page_size: 10,
          total_count: 0
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for the dashboard page (org query + preferences). */
export function createDashboardHandlers(options?: {
  orgId?: string;
  preferences?: Record<string, unknown>;
}): ApiHandler[] {
  const orgId = options?.orgId ?? "org-1";
  const preferences = options?.preferences ?? {};

  return [
    request => {
      const pathname = getPathname(request);

      // GET /api/identity/orgs/:orgId (single-org fetch by dashboard)
      if (request.method() === "GET" && pathname === `/api/identity/orgs/${orgId}`) {
        return jsonResponse({
          organizations: [
            {
              id: orgId,
              name: "Test Organization",
              domain: "localhost:3000"
            }
          ]
        });
      }

      // GET /api/identity/orgs/:orgId/preferences
      if (
        request.method() === "GET" &&
        pathname === `/api/identity/orgs/${orgId}/preferences`
      ) {
        return jsonResponse({ preferences });
      }

      return undefined;
    }
  ];
}

/** Handlers for the workspaces listing page. */
export function createWorkspacesHandlers(options?: {
  workspaces?: Array<Record<string, unknown>>;
  totalCount?: number;
}): ApiHandler[] {
  const workspaces = options?.workspaces ?? [];
  const totalCount = options?.totalCount ?? workspaces.length;

  return [
    request => {
      const pathname = getPathname(request);

      if (request.method() === "GET" && pathname === "/api/workspaces") {
        return jsonResponse({
          workspaces,
          page: 0,
          page_size: 10,
          total_count: totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for the teams listing page. */
export function createTeamsHandlers(options?: {
  teams?: Array<Record<string, unknown>>;
  totalCount?: number;
  orgId?: string;
}): ApiHandler[] {
  const teams = options?.teams ?? [];
  const totalCount = options?.totalCount ?? teams.length;
  const orgId = options?.orgId ?? "org-1";

  return [
    request => {
      const pathname = getPathname(request);

      if (
        request.method() === "GET" &&
        pathname === `/api/identity/orgs/${orgId}/teams`
      ) {
        // Canonical team.TeamPage envelope (camelCase since schemas
        // v1.3.22); the server generates these keys from the schema.
        return jsonResponse({
          teams,
          page: 0,
          pageSize: 10,
          totalCount: totalCount
        });
      }

      // Handle users-for-org queries used by team management
      if (
        request.method() === "GET" &&
        pathname === `/api/identity/orgs/${orgId}/users`
      ) {
        return jsonResponse({ users: [], total_count: 0 });
      }

      return undefined;
    }
  ];
}

/** Handlers for the catalog page. */
export function createCatalogHandlers(options?: {
  patterns?: Array<Record<string, unknown>>;
  totalCount?: number;
}): ApiHandler[] {
  const patterns = options?.patterns ?? [];
  const totalCount = options?.totalCount ?? patterns.length;

  return [
    request => {
      const pathname = getPathname(request);

      // GET /api/catalog/content/classes returns a bare ARRAY, not the
      // paginated object below, and the catalog filter maps it directly
      // (`components/catalog/filter-component` -> `(classes || []).map`). The
      // paginated object is truthy, so it slips past that `|| []` guard and
      // throws `classes.map is not a function`, which trips the page's error
      // boundary: the whole catalog subtree - CloudHead included - is replaced
      // by the "Try Again" panel, so the document title and every meta tag go
      // empty. That is why catalog.spec's title assertions failed. This case
      // must stay AHEAD of the prefix match below, which would otherwise claim
      // it. createFallbackHandlers() carries the same special case; specs that
      // use this set instead of (or before) the fallback need it here too.
      if (request.method() === "GET" && pathname === "/api/catalog/content/classes") {
        return jsonResponse([]);
      }

      // GET /api/catalog/content/pattern
      if (request.method() === "GET" && pathname.startsWith("/api/catalog/content")) {
        return jsonResponse({
          patterns,
          page: 0,
          page_size: 10,
          total_count: totalCount
        });
      }

      // GET /api/content/patterns (alternate endpoint)
      if (request.method() === "GET" && pathname === "/api/content/patterns") {
        return jsonResponse({
          patterns,
          page: 0,
          page_size: 10,
          total_count: totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for the profile page. */
export function createProfileHandlers(options?: {
  user?: Record<string, unknown>;
}): ApiHandler[] {
  const user = options?.user ?? {};

  return [
    request => {
      const pathname = getPathname(request);

      if (request.method() === "GET" && pathname === "/api/identity/users/profile") {
        return jsonResponse(user);
      }

      return undefined;
    }
  ];
}

/** Handlers for the security keys page. */
export function createKeysHandlers(options?: {
  keys?: Array<Record<string, unknown>>;
  totalCount?: number;
}): ApiHandler[] {
  const securityKeys = options?.keys ?? [];
  const totalCount = options?.totalCount ?? securityKeys.length;

  return [
    request => {
      const pathname = getPathname(request);

      if (request.method() === "GET" && pathname === "/api/auth/keys") {
        return jsonResponse({
          keys: securityKeys,
          page: 0,
          pageSize: 10,
          totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for the events overview page. */
export function createEventsHandlers(options?: { audit?: number }): ApiHandler[] {
  const audit = options?.audit ?? 0;

  return [
    request => {
      const pathname = getPathname(request);

      if (request.method() === "GET" && pathname === "/api/events") {
        return jsonResponse({ audit });
      }

      return undefined;
    }
  ];
}

/**
 * Catch-all handler that responds with a "safe" empty payload for any
 * unhandled API request. Use as the LAST handler in a chain to avoid
 * "Unhandled API request" errors for app-shell bootstrap endpoints.
 *
 * The response *shape* is important: the UI destructures with defaults like
 * `const { data: rows = [] }` and then calls `.slice/.map/.filter` on the
 * result. Returning `{}` for an endpoint that the app treats as an array
 * tanks the render with "rows.slice is not a function". So we detect the
 * shape by path convention:
 *
 *   - paths ending in `/online`, `/activeUsers`, `/notifications` → array
 *   - paginated list endpoints (keys like workspaces/patterns/events
 *     appearing anywhere in the path) → `{ [plural]: [], total_count: 0 }`
 *   - everything else → `{}`
 *
 * Specs that care about the exact payload should mock the endpoint
 * explicitly BEFORE the fallback.
 */
export function createFallbackHandlers(): ApiHandler[] {
  const listWords = [
    "workspaces",
    "patterns",
    "designs",
    "filters",
    "views",
    "catalog",
    "environments",
    "connections",
    "integrations",
    "teams",
    "roles",
    "keychains",
    "keys",
    "credentials",
    "tokens",
    "sessions",
    "events",
    "organizations",
    "users",
    "invitations",
    "badges",
    "recognitions",
    "plans",
    "subscriptions",
    "leaderboard",
    "meshmodels"
  ];

  // Emit BOTH pagination-envelope casings: constructs already recased to
  // the canonical camelCase (team/credential since schemas v1.3.22) read
  // pageSize/totalCount, while endpoints whose schema envelope is still
  // snake_case (workspace/view/role inline envelopes) read
  // page_size/total_count. Specs that care about the exact payload mock
  // their endpoint explicitly before this fallback.
  const emptyList = (key: string) => ({
    [key]: [],
    page: 0,
    pageSize: 10,
    totalCount: 0,
    page_size: 10,
    total_count: 0
  });

  return [
    request => {
      const pathname = getPathname(request);
      const last = lastPathSegment(pathname) ?? "";

      if (["online", "activeUsers", "notifications"].includes(last)) {
        return jsonResponse([]);
      }

      // `/api/catalog/content/classes` returns a bare ARRAY of content
      // classes, which the catalog page maps directly (`(classes || []).map`).
      // The paginated `{patterns:[],...}` object below is truthy, so it would
      // slip past the `|| []` guard and throw `classes.map is not a function`,
      // tripping the catalog's error boundary ("Try Again") and hiding the
      // whole grid. Answer with an empty array instead.
      if (pathname === "/api/catalog/content/classes") {
        return jsonResponse([]);
      }

      // `/api/catalog/content/pattern` (and `/...filter`, `/...view`) is
      // wrapped by `api/catalog.js::getCatalogContentWithFilters` which
      // unconditionally dereferences `data.patterns.map(...)`. Returning
      // the "catalog" list shape would crash the dashboard's catalog
      // widget on any route, so we special-case this endpoint.
      if (
        pathname === "/api/catalog/content/pattern" ||
        pathname === "/api/catalog/content/filter" ||
        pathname === "/api/catalog/content/view" ||
        pathname.startsWith("/api/catalog/content/")
      ) {
        return jsonResponse(emptyList("patterns"));
      }

      for (const word of listWords) {
        if (pathname.includes(`/${word}`) || last === word) {
          return jsonResponse(emptyList(word));
        }
      }

      return jsonResponse({});
    }
  ];
}

/**
 * Handlers for the designs/patterns CRUD endpoints. Supports listing, creating,
 * updating, and deleting patterns. Uses in-memory state so mutations are observable
 * on subsequent requests within a single test.
 *
 * Mirrors the `/api/content/patterns*` routes consumed by the UI via RTK Query
 * (see `@meshery/schemas/cloudApi`).
 */
export function createDesignsHandlers(options?: {
  patterns?: Array<Record<string, unknown>>;
  totalCount?: number;
}): ApiHandler[] {
  const patterns = [...(options?.patterns ?? [])];
  let totalCount = options?.totalCount ?? patterns.length;

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();

      // GET /api/content/patterns — list designs.
      // camelCase envelope: the component reads `patternsData?.totalCount`, so a
      // snake_case `total_count` silently renders "Total Designs: 0".
      if (method === "GET" && pathname === "/api/content/patterns") {
        return jsonResponse({
          patterns,
          page: 0,
          pageSize: 10,
          totalCount
        });
      }

      // POST /api/content/patterns — create / upsert design.
      //
      // The canonical `UpsertPatternApiArg["body"]` nests the design under
      // `patternData` (`{save, url?, patternData: {name, patternFile}}`) — a
      // top-level `name`/`pattern_file` is a shape no client sends, so read the
      // nested keys and keep the flat ones only as a fallback.
      if (method === "POST" && pathname === "/api/content/patterns") {
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const patternData = (body.patternData ?? {}) as Record<string, unknown>;
        // camelCase wire shape (AGENTS.md: "Wire is camelCase"). Sistent's
        // CatalogCard reads these fields directly and throws
        // `undefined.toString()` on a snake_case row, so an imported design must
        // come back in the same shape the real API returns or the grid blanks
        // out behind an error boundary the moment the list refetches.
        const newPattern = {
          id: `pattern-${Math.random().toString(36).substring(2, 10)}`,
          name: (patternData.name as string) ?? (body.name as string) ?? "New Design",
          patternFile:
            (patternData.patternFile as string) ?? (body.pattern_file as string) ?? "{}",
          userId: "user-1",
          visibility: "private",
          catalogData: { type: "Deployment", contentClass: "community" },
          viewCount: 0,
          cloneCount: 0,
          downloadCount: 0,
          shareCount: 0,
          createdAt: "2026-01-01T00:00:00Z",
          updatedAt: "2026-01-01T00:00:00Z"
        };
        patterns.push(newPattern);
        totalCount = patterns.length;
        return jsonResponse(newPattern, 201);
      }

      // DELETE /api/content/patterns — bulk delete designs
      if (method === "DELETE" && pathname === "/api/content/patterns") {
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const ids = Array.isArray(body.patterns)
          ? (body.patterns as Array<Record<string, unknown>>).map(p => p.id)
          : [];
        for (const id of ids) {
          const index = patterns.findIndex(p => p.id === id);
          if (index >= 0) {
            patterns.splice(index, 1);
          }
        }
        totalCount = patterns.length;
        return jsonResponse({ success: true });
      }

      // PUT /api/content/patterns/:id — update design
      if (method === "PUT" && pathname.startsWith("/api/content/patterns/")) {
        const id = lastPathSegment(pathname);
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const index = patterns.findIndex(p => p.id === id);
        if (index >= 0) {
          patterns[index] = { ...patterns[index], ...body };
          return jsonResponse(patterns[index]);
        }
        return jsonResponse({ message: "not found" }, 404);
      }

      // DELETE /api/content/patterns/:id — delete a single design
      if (method === "DELETE" && pathname.startsWith("/api/content/patterns/")) {
        const id = lastPathSegment(pathname);
        const index = patterns.findIndex(p => p.id === id);
        if (index >= 0) {
          patterns.splice(index, 1);
          totalCount = patterns.length;
        }
        return jsonResponse({ success: true });
      }

      return undefined;
    }
  ];
}

/**
 * Handlers for the connections setup wizard. Supports listing connection meshmodels
 * and creating a new connection.
 */
export function createConnectionsHandlers(options?: {
  connections?: Array<Record<string, unknown>>;
}): ApiHandler[] {
  const connections = [...(options?.connections ?? [])];

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();

      // GET /api/integrations/connections — list connections
      if (
        method === "GET" &&
        (pathname === "/api/integrations/connections" || pathname === "/api/connections")
      ) {
        return jsonResponse({
          connections,
          page: 0,
          page_size: 10,
          total_count: connections.length
        });
      }

      // POST /api/integrations/connections — create a new connection
      if (
        method === "POST" &&
        (pathname === "/api/integrations/connections" || pathname === "/api/connections")
      ) {
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const newConnection = {
          id: `conn-${connections.length + 1}`,
          name: (body.name as string) ?? "New Connection",
          ...body
        };
        connections.push(newConnection);
        return jsonResponse(newConnection, 201);
      }

      // GET /api/integrations/meshmodels/models — supported connection types
      if (method === "GET" && pathname === "/api/integrations/meshmodels/models") {
        return jsonResponse({
          models: [],
          page: 0,
          page_size: 25,
          total_count: 0
        });
      }

      // GET /api/integrations/meshmodels/categories — meshmodel categories
      if (method === "GET" && pathname === "/api/integrations/meshmodels/categories") {
        return jsonResponse({
          categories: [],
          page: 0,
          page_size: 25,
          total_count: 0
        });
      }

      return undefined;
    }
  ];
}

/**
 * Handlers for the GitHub connection wizard's own endpoints - the ones under
 * `/api/integrations/github/*` served by `server/handlers/github.go`. These are
 * distinct from `createConnectionsHandlers`, which answers the generic
 * `/api/integrations/connections` listing the wizard uses to decide between the
 * `new` and `reconfigure` legs.
 *
 * `metadataShape` selects which spelling of the connection metadata keys the
 * repository listing is driven from. The server flipped these to canonical
 * camelCase in commit 53cc2166 and the UI keeps a snake_case fallback for rows
 * written before the flip (`readGithubMetadata` in
 * `components/connect/stepper/github.tsx`), so both shapes are exercised.
 *
 * `statusCode` drives `GET /api/integrations/github/status`, the "return leg"
 * probe `ConnectionVerify` blocks on: 200 = installation confirmed, 404 = the
 * installation is gone and the server has dropped the connection row, 500 =
 * the status check itself failed.
 */
export function createGithubWizardHandlers(options?: {
  repositories?: Array<{ name: string; owner: { login: string } }>;
  statusCode?: number;
  installFailsFor?: string[];
}): ApiHandler[] {
  const repositories = options?.repositories ?? [
    { name: "sample-repo", owner: { login: "octo-org" } }
  ];
  const statusCode = options?.statusCode ?? 200;
  const installFailsFor = options?.installFailsFor ?? [];

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();
      const url = new URL(request.url());

      // GET /api/integrations/github/status - the installation "return leg"
      // probe. Answers with no body; only the status code is read.
      if (method === "GET" && pathname === "/api/integrations/github/status") {
        return {
          body: statusCode === 200 ? "" : "unable to get connection details",
          status: statusCode,
          contentType: "text/plain"
        };
      }

      // GET /api/integrations/github?id=<installationId>&page=N - repositories
      // reachable by this installation. The wizard pages until it gets an
      // empty array, so only page 0 carries rows.
      if (method === "GET" && pathname === "/api/integrations/github") {
        const page = Number(url.searchParams.get("page") ?? "0");
        return jsonResponse({
          repositories: page === 0 ? repositories : [],
          total_count: repositories.length
        });
      }

      // POST /api/integrations/github/install?id=<installationId> - writes the
      // Kanvas Snapshot workflow into each selected repository. Mirrors the
      // real handler's per-repository `{ "<repo>": { code, description } }`
      // result shape, where anything other than 201 is treated as a failure by
      // `workflowStatus`.
      if (method === "POST" && pathname === "/api/integrations/github/install") {
        let body: { repositories?: string[] } = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as { repositories?: string[] };
        } catch {
          // ignore - an unparseable body yields an empty result set below
        }
        return jsonResponse(
          (body.repositories ?? []).map(repo => ({
            [repo]: installFailsFor.includes(repo)
              ? { code: 422, description: `workflow already exists in ${repo}` }
              : { code: 201, description: "workflow created" }
          }))
        );
      }

      if (method === "POST" && pathname === "/api/integrations/github/metadata") {
        return jsonResponse({});
      }

      if (method === "GET" && pathname === "/api/integrations/github/scan") {
        return jsonResponse({ name: "root", type: "dir", children: [] });
      }

      return undefined;
    }
  ];
}

/**
 * Builds the `/api/integrations/connections` payload for an already-connected
 * GitHub App, in either metadata spelling. `snake` reproduces a row written
 * before the canonical-camelCase flip (commit 53cc2166) so the UI's
 * `readGithubMetadata` fallback is covered by a real browser run rather than
 * only by its unit test.
 */
export function githubConnectionFixture(options?: {
  id?: string;
  installationId?: string;
  metadataShape?: "camel" | "snake";
  snapshotPaths?: Array<Record<string, string>>;
}): Record<string, unknown> {
  const id = options?.id ?? "gh-conn-1";
  const installationId = options?.installationId ?? "9911";
  const snapshotPaths = options?.snapshotPaths ?? [];
  const metadata =
    options?.metadataShape === "snake"
      ? { installation_id: installationId, snapshot_paths: snapshotPaths }
      : { installationId, snapshotPaths };

  return {
    id,
    name: "GitHub App",
    kind: "github",
    type: "source",
    sub_type: "git",
    status: "connected",
    metadata
  };
}

/**
 * Handlers for organization invitations. Supports listing invitations, sending a
 * new invitation, and accepting a pending invitation.
 *
 * Mirrors the `/api/organizations/invitations*` routes consumed by the UI via
 * RTK Query (see `@meshery/schemas/cloudApi`) and served by the backend
 * `server/handlers/invitations` package.
 */
export function createInvitationsHandlers(options?: {
  invitations?: Array<Record<string, unknown>>;
  orgId?: string;
}): ApiHandler[] {
  const orgId = options?.orgId ?? "org-1";
  const nowIso = () => new Date().toISOString();
  const normalizeInvitation = (
    invitation: Record<string, unknown>,
    existing?: Record<string, unknown>
  ): Record<string, unknown> => {
    const source = { ...(existing ?? {}), ...invitation };
    const owner = String(source.owner ?? source.ownerId ?? source.owner_id ?? "user-1");
    const organizationId = String(source.orgId ?? source.org_id ?? orgId);
    const acceptedBy = Array.isArray(source.acceptedBy)
      ? source.acceptedBy
      : Array.isArray(source.accepted_by)
        ? source.accepted_by
        : [];
    const createdAt = String(
      source.createdAt ?? source.created_at ?? existing?.createdAt ?? nowIso()
    );
    const updatedAt = String(source.updatedAt ?? source.updated_at ?? nowIso());
    const deletedAt = String(source.deletedAt ?? source.deleted_at ?? "");
    // `Invitation.ExpiresAt` is a `*time.Time` with no `omitempty`, so an
    // invitation that never expires reaches the client as `null` - never as
    // `""`, which is not a valid `date-time` and marks the field invalid.
    const expiresAt = source.expiresAt ?? source.expires_at ?? null;
    const rawQuota = source.quota;
    const quota =
      rawQuota === undefined || rawQuota === null || rawQuota === ""
        ? undefined
        : Number(rawQuota);
    const isDefault = Boolean(source.isDefault ?? source.is_default ?? false);

    // Serve the row the way the PROVIDER serves it: camelCase only.
    //
    // This used to emit every field under both spellings. The server binds the
    // v1beta3 Invitation construct, which is camelCase-only, so the snake_case
    // half was a value the wire cannot carry - and it was not inert. The edit
    // modal seeds its RJSF form from the row, that schema sets
    // `additionalProperties: false`, and each extra key raised a validation
    // error, so the Update button silently did nothing: no request, no
    // notification, only a console line. Reading either spelling on the way IN
    // is still fine (below) - it is emitting the invented one that broke.
    return {
      ...source,
      id: String(source.id ?? `invite-${Math.random().toString(36).substring(2, 10)}`),
      owner,
      isDefault,
      name: String(source.name ?? ""),
      description: String(source.description ?? ""),
      emails: Array.isArray(source.emails) ? source.emails : [],
      orgId: organizationId,
      expiresAt,
      quota,
      acceptedBy,
      roles: Array.isArray(source.roles) ? source.roles : [],
      teams: Array.isArray(source.teams) ? source.teams : [],
      status: source.status === "disabled" ? "disabled" : "enabled",
      createdAt,
      updatedAt,
      deletedAt
    };
  };
  const invitations = (options?.invitations ?? []).map(invitation =>
    normalizeInvitation(invitation)
  );

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();

      // GET /api/organizations/invitations — list invitations for the
      // current org context.
      if (method === "GET" && pathname === "/api/organizations/invitations") {
        return jsonResponse({
          data: invitations,
          total: invitations.length
        });
      }

      // POST /api/organizations/invitations — create a new invitation.
      if (method === "POST" && pathname === "/api/organizations/invitations") {
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const newInvitation = normalizeInvitation(body);
        invitations.push(newInvitation);
        return jsonResponse(newInvitation, 201);
      }

      // GET /api/organizations/invitations/:invitationId — fetch a single
      // invitation by id.
      if (
        method === "GET" &&
        pathname.startsWith("/api/organizations/invitations/") &&
        !pathname.endsWith("/accept")
      ) {
        const id = lastPathSegment(pathname);
        const found = invitations.find(i => i.id === id);
        if (found) {
          return jsonResponse(found);
        }
        return jsonResponse({ message: "not found" }, 404);
      }

      // PUT /api/organizations/invitations/:invitationId — update an
      // existing invitation.
      if (
        method === "PUT" &&
        pathname.startsWith("/api/organizations/invitations/") &&
        !pathname.endsWith("/accept")
      ) {
        const id = lastPathSegment(pathname);
        const index = invitations.findIndex(i => i.id === id);
        if (index < 0) {
          return jsonResponse({ message: "not found" }, 404);
        }
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const updatedInvitation = normalizeInvitation(body, invitations[index]);
        invitations[index] = updatedInvitation;
        return jsonResponse(updatedInvitation);
      }

      // DELETE /api/organizations/invitations/:invitationId — revoke an
      // invitation.
      if (
        method === "DELETE" &&
        pathname.startsWith("/api/organizations/invitations/") &&
        !pathname.endsWith("/accept")
      ) {
        const id = lastPathSegment(pathname);
        const index = invitations.findIndex(i => i.id === id);
        if (index >= 0) {
          invitations.splice(index, 1);
        }
        return jsonResponse({ success: true });
      }

      // POST /api/organizations/invitations/:invitationId/accept — accept a
      // pending invitation. Use the path segment preceding `/accept`.
      if (
        method === "POST" &&
        pathname.startsWith("/api/organizations/invitations/") &&
        pathname.endsWith("/accept")
      ) {
        const id = secondToLastPathSegment(pathname);
        const found = invitations.find(i => i.id === id);
        if (found) {
          const acceptedBy = Array.isArray(found.acceptedBy) ? found.acceptedBy : [];
          found.acceptedBy = [...acceptedBy, "user-1"];
          found.accepted_by = found.acceptedBy;
        }
        return jsonResponse({ id, orgId: orgId, org_id: orgId, status: "accepted" });
      }

      // POST /api/identity/orgs/:orgId/users/invite — legacy invite flow
      // used by the org edit modal. Keep compatibility for tests that invoke
      // this helper for that UI surface.
      if (method === "POST" && pathname === `/api/identity/orgs/${orgId}/users/invite`) {
        return jsonResponse({ success: true }, 201);
      }

      return undefined;
    }
  ];
}

/**
 * Handlers for the subscriptions / plans page. Returns a list of plans and mocks
 * checkout session creation to avoid real Stripe interactions.
 */
export function createSubscriptionsHandlers(options?: {
  plans?: Array<Record<string, unknown>>;
  currentPlan?: string;
}): ApiHandler[] {
  const plans = options?.plans ?? [
    {
      id: "plan-free",
      name: "Free",
      price: 0,
      interval: "month"
    },
    {
      id: "plan-team",
      name: "Team",
      price: 49,
      interval: "month"
    }
  ];
  const currentPlan = options?.currentPlan ?? "plan-free";

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();

      // GET /api/plans, /api/entitlement/plans, /api/subscriptions/plans —
      // the UI hook `useGetPlansQuery` destructures directly as an array
      // (`allPlans?.filter(...)`), so the response body MUST be an array,
      // NOT `{plans: [...], current_plan: ...}`.
      if (
        method === "GET" &&
        (pathname === "/api/plans" ||
          pathname === "/api/entitlement/plans" ||
          pathname === "/api/subscriptions/plans" ||
          pathname === "/api/subscription/plans")
      ) {
        return jsonResponse(plans);
      }

      // GET /api/subscriptions/current (or /api/subscription)
      if (
        method === "GET" &&
        (pathname === "/api/subscription" || pathname === "/api/subscriptions/current")
      ) {
        return jsonResponse({ plan: currentPlan });
      }

      // POST /api/subscription/checkout — Stripe checkout session creation
      if (
        method === "POST" &&
        (pathname === "/api/subscription/checkout" ||
          pathname === "/api/subscriptions/checkout" ||
          pathname === "/api/billing/checkout")
      ) {
        return jsonResponse({
          url: "https://checkout.stripe.com/c/pay/test_session_id",
          session_id: "cs_test_stub"
        });
      }

      return undefined;
    }
  ];
}

/**
 * Wire shape of one models.UserToken row (`server/models/users.go`) as the
 * `/api/identity/tokens*` routes serve it. Taken FROM the generated operation
 * rather than restated, so a fixture reaching for a DB column spelling -
 * `created_at`, the one that let the blank Creation Date bug stay green - or
 * omitting a field the table reads is a `tsc` error at the call site instead of
 * a silently empty cell, and an upstream change to the required set propagates
 * here instead of drifting.
 *
 * `provider` is the one local relaxation, and it is the provider's wire that
 * says so: `UsersDao.GetTokens` selects id / name / purpose / owner /
 * created_at only, and `Provider` carries `json:"provider,omitempty"`, so this
 * endpoint never sends the key. Requiring it would make every fixture claim a
 * field the server omits.
 */
export type UserTokenFixture = Omit<
  GetUserTokensApiResponse["tokens"][number],
  "provider"
> & { provider?: string };

/**
 * Handlers for API tokens management page.
 *
 * Mirrors the `/api/identity/tokens*` routes consumed by the UI via RTK Query
 * (see `@meshery/schemas/cloudApi`).
 */
export function createTokensHandlers(options?: {
  tokens?: UserTokenFixture[];
}): ApiHandler[] {
  const tokens: UserTokenFixture[] = [...(options?.tokens ?? [])];

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();

      // GET /api/identity/tokens — list tokens.
      // Envelope keys are the ones models.TokensPage actually serves
      // (camelCase); the snake_case spellings this used to return are read by
      // nothing in the component, so the fixture agreed with no server.
      if (method === "GET" && pathname === "/api/identity/tokens") {
        return jsonResponse({
          tokens,
          page: 0,
          pageSize: 10,
          totalCount: tokens.length
        });
      }

      // POST /api/identity/tokens — create a token. GenerateToken
      // (server/handlers/users.go) answers 200 with a models.TokensPage
      // envelope, but the row inside it is the struct it passed BY VALUE to
      // UsersDao.IssueTokens, which INSERTs its own id and time.Now() and
      // writes neither back — so the real create response carries a zero uuid
      // and a zero createdAt, and only the subsequent GET has the persisted
      // values. Both halves are reproduced here: a hollow response body, and a
      // realistic row in the list the GET branch serves.
      if (method === "POST" && pathname === "/api/identity/tokens") {
        const url = new URL(request.url());
        const name = url.searchParams.get("name") ?? "Generated Token";
        const purpose = url.searchParams.get("purpose") ?? "";
        tokens.push({
          id: `tok-${Math.random().toString(36).substring(2, 10)}`,
          owner: "user-1",
          name,
          purpose,
          isOauth: false,
          accessToken: "tk-abcdefghij",
          createdAt: "2026-01-01T00:00:00Z",
          updatedAt: "2026-01-01T00:00:00Z"
        });
        return jsonResponse({
          tokens: [
            {
              id: "00000000-0000-0000-0000-000000000000",
              name,
              purpose,
              isOauth: false,
              accessToken: "tk-abcdefghij",
              createdAt: "0001-01-01T00:00:00Z",
              updatedAt: "0001-01-01T00:00:00Z"
            }
          ],
          page: 0,
          pageSize: 1,
          totalCount: 1
        });
      }

      // DELETE /api/identity/tokens — bulk delete tokens via query params.
      if (method === "DELETE" && pathname === "/api/identity/tokens") {
        const url = new URL(request.url());
        // Mirrors utils.QueryParam in DeleteUserTokens: camelCase wins, the
        // legacy snake_case spelling is still accepted. The client sends
        // `tokenId`, so a fixture reading only `token_id` matched nothing.
        const tokenId =
          url.searchParams.get("tokenId") ?? url.searchParams.get("token_id");
        const tokenName = url.searchParams.get("token_name");
        const matches = (t: UserTokenFixture): boolean => {
          if (tokenId && t.id === tokenId) return true;
          if (tokenName && t.name === tokenName) return true;
          return false;
        };
        for (let i = tokens.length - 1; i >= 0; i--) {
          if (matches(tokens[i])) {
            tokens.splice(i, 1);
          }
        }
        return jsonResponse({ success: true });
      }

      // GET /api/identity/tokens/:id — fetch a single token by id
      if (
        method === "GET" &&
        pathname.startsWith("/api/identity/tokens/") &&
        pathname !== "/api/identity/tokens/infinite"
      ) {
        const id = lastPathSegment(pathname);
        const found = tokens.find(t => t.id === id);
        if (found) {
          return jsonResponse(found);
        }
        return jsonResponse({ message: "not found" }, 404);
      }

      // DELETE /api/identity/tokens/:id — delete a token by id. Mutates the
      // internal list so subsequent list calls reflect the deletion.
      if (method === "DELETE" && pathname.startsWith("/api/identity/tokens/")) {
        const id = lastPathSegment(pathname);
        const index = tokens.findIndex(t => t.id === id);
        if (index >= 0) {
          tokens.splice(index, 1);
        }
        return jsonResponse({ success: true });
      }

      return undefined;
    }
  ];
}

/**
 * Handlers for the keychains list page. Mirrors
 * `GET /api/identity/orgs/:orgId/keychains` consumed by the UI via RTK Query.
 */
export function createKeychainsHandlers(options?: {
  keychains?: Array<Record<string, unknown>>;
  totalCount?: number;
  orgId?: string;
}): ApiHandler[] {
  const keychains = options?.keychains ?? [];
  const totalCount = options?.totalCount ?? keychains.length;
  const orgId = options?.orgId ?? "org-1";

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (
        method === "GET" &&
        (pathname === `/api/identity/orgs/${orgId}/keychains` ||
          pathname === "/api/keychains" ||
          pathname === "/api/auth/keychains")
      ) {
        return jsonResponse({
          keychains,
          page: 0,
          pageSize: 10,
          totalCount
        });
      }

      if (
        method === "GET" &&
        pathname.startsWith(`/api/identity/orgs/${orgId}/keychains/`)
      ) {
        const id = lastPathSegment(pathname);
        const found = keychains.find(k => k.id === id);
        if (found) {
          return jsonResponse(found);
        }
        return jsonResponse({ message: "not found" }, 404);
      }

      return undefined;
    }
  ];
}

/** Handlers for `/security/credentials`. */
export function createCredentialsHandlers(options?: {
  credentials?: Array<Record<string, unknown>>;
  totalCount?: number;
  orgId?: string;
}): ApiHandler[] {
  const credentials = options?.credentials ?? [];
  const totalCount = options?.totalCount ?? credentials.length;
  const orgId = options?.orgId ?? "org-1";

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (
        method === "GET" &&
        (pathname === `/api/identity/orgs/${orgId}/credentials` ||
          pathname === "/api/credentials" ||
          // Canonical getUserCredentials path served by the generated
          // cloudApi client.
          pathname === "/api/integrations/credentials")
      ) {
        // Canonical credential.CredentialPage envelope (camelCase since
        // schemas v1.3.22); the server generates these keys from the schema.
        return jsonResponse({
          credentials,
          page: 0,
          pageSize: 10,
          totalCount: totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for `/spaces/environments`. */
export function createEnvironmentsHandlers(options?: {
  environments?: Array<Record<string, unknown>>;
  totalCount?: number;
}): ApiHandler[] {
  const environments = options?.environments ?? [];
  const totalCount = options?.totalCount ?? environments.length;

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (method === "GET" && pathname === "/api/environments") {
        return jsonResponse({
          environments,
          page: 0,
          page_size: 10,
          total_count: totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for `/identity/roles` with a custom role list payload. */
export function createRolesHandlers(options?: {
  roles?: Array<Record<string, unknown>>;
  totalCount?: number;
  orgId?: string;
}): ApiHandler[] {
  const roles = options?.roles ?? [];
  const totalCount = options?.totalCount ?? roles.length;
  const orgId = options?.orgId ?? "org-1";

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (method === "GET" && pathname === `/api/identity/orgs/${orgId}/roles`) {
        return jsonResponse({
          roles,
          page: 0,
          pageSize: 10,
          totalCount: totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for `/events/audit`. */
export function createEventsAuditHandlers(options?: {
  events?: Array<Record<string, unknown>>;
  totalCount?: number;
}): ApiHandler[] {
  const events = options?.events ?? [];
  const totalCount = options?.totalCount ?? events.length;

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (
        method === "GET" &&
        (pathname === "/api/events/audit" || pathname === "/api/events/pages")
      ) {
        return jsonResponse({
          events,
          page: 0,
          page_size: 10,
          total_count: totalCount
        });
      }

      return undefined;
    }
  ];
}

/** Handlers for `/catalog/leaderboard`. */
export function createLeaderboardHandlers(options?: {
  leaderboard?: Array<Record<string, unknown>>;
}): ApiHandler[] {
  const leaderboard = options?.leaderboard ?? [];

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (
        method === "GET" &&
        (pathname === "/api/catalog/leaderboard" ||
          pathname === "/api/content/leaderboard")
      ) {
        return jsonResponse({
          leaderboard,
          total_count: leaderboard.length
        });
      }

      return undefined;
    }
  ];
}

/**
 * Handler for `/user/:userid` — the public user profile page. Mirrors
 * `GET /api/identity/users/:id` while leaving the shell-bootstrap endpoints
 * (`/profile`, `/online`, `/provider`) to `createSharedShellHandlers` and
 * `createAuthenticatedShellHandlers`.
 */
export function createPublicProfileHandlers(options?: {
  user?: Record<string, unknown>;
}): ApiHandler[] {
  const user = options?.user ?? {};

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (method === "GET" && pathname.startsWith("/api/identity/users/")) {
        const last = lastPathSegment(pathname) ?? "";
        if (last === "profile" || last === "online" || last === "provider") {
          return undefined;
        }
        return jsonResponse(user);
      }

      return undefined;
    }
  ];
}

// -----------------------------------------------------------------------------
// Permission keys (used by both permissions.spec.ts and the deep workspace /
// catalog specs that assert on gated affordances).
//
// Every entry is a direct reference INTO `@meshery/schemas/permissions` (Keys),
// the single source of truth for permission ids and subjects: the UI ability
// engine (@casl/ability) looks up `{ action: <uuid>, subject: <lowercased
// function> }` against the ability rules produced by
// `api/user-keys.ts::useGetUserAbilities`. Returning these from
// `createPermissionKeysHandler` grants the corresponding CAN() gates — anything
// omitted is denied.
//
// These MUST NOT be re-typed as literal uuid/function pairs. `canKey` matches
// on BOTH `.id` (the CASL action) and `.function` (the subject), so a
// hand-copied fixture drifts silently as soon as either one changes in
// `meshery/schemas` - and it drifts in both directions: the mock either keeps
// granting a stale value while every gated spec stays green and the app ships
// broken, or it quietly revokes the grant so the page under test renders its
// not-authorized state, which is exactly what had happened to the roles and
// academy fixtures. Sourcing the fixture from `Keys` makes a renamed member a
// type error, which fails both `next build` and `npm run typecheck` - the
// latter compiles `tsconfig.jest.json`, whose file set spans the whole `ui/`
// tree, this directory included. The Jest key-existence guard
// (`ui/__tests__/architecture/permission-key-existence.test.ts`) scans this
// file too: `e2e` is deliberately absent from its SKIP_DIR_NAMES.
//
// The map keys below are the stable, test-facing aliases specs read; the values
// are whatever the schema currently generates.
// -----------------------------------------------------------------------------

export const PERMISSION_KEYS = {
  VIEW_WORKSPACE: Keys.WorkspaceManagementViewWorkspace,
  CREATE_WORKSPACE: Keys.WorkspaceManagementCreateWorkspace,
  EDIT_WORKSPACE: Keys.WorkspaceManagementEditWorkspace,
  DELETE_WORKSPACE: Keys.WorkspaceManagementDeleteWorkspace,
  ASSIGN_TEAM_TO_WORKSPACE: Keys.WorkspaceManagementAssignTeamToWorkspace,
  VIEW_CATALOG: Keys.CatalogManagementViewCatalog,
  VIEW_DESIGNS: Keys.CatalogManagementViewDesigns,
  UNPUBLISH_DESIGN: Keys.CatalogManagementUnpublishDesign,
  PUBLISH_DESIGN: Keys.CatalogManagementPublishDesign,
  DELETE_A_DESIGN: Keys.CatalogManagementDeleteADesign,
  VIEW_ALL_ORGANIZATIONS: Keys.IdentityAccessManagementViewAllOrganizations,
  VIEW_ORGANIZATIONS: Keys.IdentityAccessManagementViewOrg,
  EDIT_ORGANIZATION: Keys.IdentityAccessManagementEditOrganization,
  ALL_ORG_SELECTOR: Keys.IdentityAccessManagementAllOrgSelector,
  // The seeded subject carries a typo ("Subcription"); the schema is the SSOT
  // for it, so referencing the key keeps the fixture and the UI in lock-step.
  VIEW_SUBSCRIPTIONS: Keys.AccountManagementViewSubcription,
  MANAGE_SUBSCRIPTIONS: Keys.AccountManagementManageSubscriptions,
  CREATE_TOKEN: Keys.SecurityManagementCreateToken,
  VIEW_TOKENS: Keys.SecurityManagementViewTokens,
  VIEW_ALL_TEAMS: Keys.IdentityAccessManagementViewAllTeams,
  VIEW_ALL_USERS: Keys.IdentityAccessManagementViewAllUsers,
  EDIT_USER: Keys.IdentityAccessManagementEditUser,
  UPDATE_USER_PROFILE: Keys.IdentityAccessManagementUpdateUserProfile,
  ASSIGN_USER_ROLES: Keys.IdentityAccessManagementAssignUserRoles,
  VIEW_KEYS: Keys.SecurityManagementViewKeys,
  VIEW_PROFILE: Keys.AccountManagementViewProfile,
  VIEW_PLANS: Keys.AccountManagementViewPlans,
  VIEW_ACADEMY: Keys.AcademyViewAcademy,
  VIEW_ACADEMY_METRICS: Keys.AcademyViewAcademyMetrics,
  VIEW_EVENTS: Keys.EventsManagementViewEvents,
  VIEW_KEYCHAINS: Keys.SecurityManagementViewKeychains,
  VIEW_CREDENTIALS: Keys.SecurityManagementViewCredentials,
  CREATE_CREDENTIAL: Keys.SecurityManagementCreateCredential,
  EDIT_CREDENTIAL: Keys.SecurityManagementEditCredential,
  DELETE_CREDENTIAL: Keys.SecurityManagementDeleteCredential,
  // The subject is singular ("View Environment") even though the alias is not.
  VIEW_ENVIRONMENTS: Keys.WorkspaceManagementViewEnvironment,
  CREATE_ENVIRONMENT: Keys.WorkspaceManagementCreateEnvironment,
  ASSIGN_CONNECTIONS_TO_ENVIRONMENT:
    Keys.WorkspaceManagementAssignConnectionsToEnvironment,
  REMOVE_CONNECTIONS_FROM_ENVIRONMENT:
    Keys.WorkspaceManagementRemoveConnectionsFromEnvironment,
  VIEW_ALL_ROLES: Keys.IdentityAccessManagementViewAllRoles,
  VIEW_ALL_ACCESS_REQUESTS: Keys.IdentityAccessManagementViewAllAccessRequests
} as const satisfies Record<string, { id: string; function: string }>;

export type PermissionKey = keyof typeof PERMISSION_KEYS;

/**
 * Returns a handler that intercepts
 * `GET /api/identity/orgs/:orgId/users/keys` and returns the set of ability
 * keys that correspond to `granted`. Use INSTEAD of the `keys` option on
 * `createAuthenticatedShellHandlers` when a test needs specific permissions.
 *
 * Because handlers run in order, place this BEFORE
 * `createAuthenticatedShellHandlers` or pass `skipKeys: true` to that helper
 * so the default empty-keys fallback does not fire first.
 */
export function createPermissionKeysHandler(
  granted: PermissionKey[],
  options?: { orgId?: string }
): ApiHandler[] {
  const orgId = options?.orgId ?? "org-1";
  const keys = granted.map(k => PERMISSION_KEYS[k]);

  return [
    request => {
      const pathname = getPathname(request);
      if (
        request.method() === "GET" &&
        (pathname === `/api/identity/orgs/${orgId}/users/keys` ||
          pathname.match(/\/api\/identity\/orgs\/[^/]+\/users\/keys/))
      ) {
        return jsonResponse({ keys });
      }
      return undefined;
    }
  ];
}

// -----------------------------------------------------------------------------
// Deep workspaces handler — full CRUD + search + sort + pagination.
//
// Mirrors the real cloud API routes so a Playwright spec can drive the
// workspace page through its complete lifecycle. State is held in-memory per
// helper invocation, so each `test(...)` gets a clean store.
// -----------------------------------------------------------------------------

export function createWorkspacesCRUDHandlers(options?: {
  workspaces?: Array<Record<string, unknown>>;
  orgId?: string;
  teams?: Array<Record<string, unknown>>;
}): ApiHandler[] {
  const initialWorkspaces = [...(options?.workspaces ?? [])];
  let workspaces = [...initialWorkspaces];
  const orgId = options?.orgId ?? "org-1";
  const teams = [...(options?.teams ?? [])];
  // teamId -> Set<workspaceId>
  const teamWorkspaceAssignments = new Map<string, Set<string>>();
  let idCounter = workspaces.length + 1;

  const nextId = () => `ws-${idCounter++}`;

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();
      const url = new URL(request.url());

      // GET /api/workspaces — list with search/order/pagination
      if (method === "GET" && pathname === "/api/workspaces") {
        const search = (url.searchParams.get("search") ?? "").toLowerCase();
        const order = url.searchParams.get("order") ?? "updated_at desc";
        const page = Number(url.searchParams.get("page") ?? 0);
        const pageSize = Number(url.searchParams.get("pagesize") ?? 10);

        let filtered = workspaces.filter(
          w =>
            !search ||
            String(w.name ?? "")
              .toLowerCase()
              .includes(search) ||
            String(w.description ?? "")
              .toLowerCase()
              .includes(search)
        );

        const [col, dir] = order.split(" ");
        filtered = [...filtered].sort((a, b) => {
          const av = String(a[col] ?? "");
          const bv = String(b[col] ?? "");
          const cmp = av.localeCompare(bv);
          return dir === "desc" ? -cmp : cmp;
        });

        const sliced = filtered.slice(page * pageSize, (page + 1) * pageSize);

        return jsonResponse({
          workspaces: sliced,
          page,
          page_size: pageSize,
          total_count: filtered.length
        });
      }

      // POST /api/workspaces — create
      if (method === "POST" && pathname === "/api/workspaces") {
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const created = {
          id: nextId(),
          name: body.name ?? "Untitled Workspace",
          description: body.description ?? "",
          organization_id: body.organization_id ?? orgId,
          owner_id: "user-1",
          owner_email: "test@example.com",
          created_at: "2026-01-01T00:00:00Z",
          updated_at: "2026-01-01T00:00:00Z"
        };
        workspaces.push(created);
        return jsonResponse(created, 201);
      }

      // PUT /api/workspaces/:id — update
      if (method === "PUT" && pathname.startsWith("/api/workspaces/")) {
        const id = lastPathSegment(pathname);
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const index = workspaces.findIndex(w => w.id === id);
        if (index >= 0) {
          workspaces[index] = { ...workspaces[index], ...body };
          return jsonResponse(workspaces[index]);
        }
        return jsonResponse({ message: "not found" }, 404);
      }

      // DELETE /api/workspaces/:id
      if (method === "DELETE" && pathname.startsWith("/api/workspaces/")) {
        const last = lastPathSegment(pathname);
        // If url is /api/workspaces/:id/teams/:teamId -> assignment
        // Handled below.
        if (pathname.match(/\/api\/workspaces\/[^/]+\/teams\/[^/]+/)) {
          const segments = pathname.split("/").filter(Boolean);
          const wsId = segments[2];
          const teamId = segments[4];
          teamWorkspaceAssignments.get(teamId)?.delete(wsId);
          return jsonResponse({ success: true });
        }
        const index = workspaces.findIndex(w => w.id === last);
        if (index >= 0) {
          workspaces.splice(index, 1);
        }
        return jsonResponse({ success: true });
      }

      // GET /api/workspaces/:id/teams — teams-of-workspace
      if (method === "GET" && pathname.match(/^\/api\/workspaces\/[^/]+\/teams$/)) {
        const segments = pathname.split("/").filter(Boolean);
        const wsId = segments[2];
        const assigned = teams.filter(t =>
          teamWorkspaceAssignments.get(String(t.id))?.has(wsId)
        );
        return jsonResponse({
          teams: assigned,
          page: 0,
          page_size: 10,
          total_count: assigned.length
        });
      }

      // POST /api/workspaces/:id/teams/:teamId — assign team
      if (
        method === "POST" &&
        pathname.match(/^\/api\/workspaces\/[^/]+\/teams\/[^/]+$/)
      ) {
        const segments = pathname.split("/").filter(Boolean);
        const wsId = segments[2];
        const teamId = segments[4];
        const set = teamWorkspaceAssignments.get(teamId) ?? new Set<string>();
        set.add(wsId);
        teamWorkspaceAssignments.set(teamId, set);
        return jsonResponse({ success: true }, 201);
      }

      // GET /api/workspaces/:id/events — recent activity
      if (method === "GET" && pathname.match(/^\/api\/workspaces\/[^/]+\/events$/)) {
        return jsonResponse({
          events: [],
          page: 0,
          page_size: 10,
          total_count: 0
        });
      }

      return undefined;
    }
  ];
}

// -----------------------------------------------------------------------------
// Deep catalog handler — list + search + sort + filter + unpublish + author
// profile. Supports both the legacy `/api/catalog/content` path and the
// newer `/api/content/patterns` path that the RTK Query generated code hits.
// -----------------------------------------------------------------------------

export function createCatalogCRUDHandlers(options?: {
  patterns?: Array<Record<string, unknown>>;
  authors?: Array<Record<string, unknown>>;
}): ApiHandler[] {
  let patterns = [...(options?.patterns ?? [])];
  const authors = options?.authors ?? [];

  const paginate = (rows: Array<Record<string, unknown>>, url: URL) => {
    const search = (url.searchParams.get("search") ?? "").toLowerCase();
    // `||` not `??`: an explicit but empty `?order=` yields "" (not null), which
    // would split into an undefined direction and sort on a[""]. Fall back on
    // both the missing and empty cases.
    const order = url.searchParams.get("order") || "updatedAt desc";
    const page = Number(url.searchParams.get("page") ?? 0);
    const pageSize = Number(url.searchParams.get("pagesize") ?? 10);
    const visibility = url.searchParams.get("visibility");
    const userid = url.searchParams.getAll("userid");

    let filtered = rows.filter(
      p =>
        !search ||
        String(p.name ?? "")
          .toLowerCase()
          .includes(search)
    );
    if (visibility) {
      filtered = filtered.filter(p => p.visibility === visibility);
    }
    if (userid.length > 0) {
      filtered = filtered.filter(p => userid.includes(String(p.userId)));
    }
    const [col, dir] = order.split(" ");
    filtered = [...filtered].sort((a, b) => {
      const av = String(a[col] ?? "");
      const bv = String(b[col] ?? "");
      const cmp = av.localeCompare(bv);
      return dir === "desc" ? -cmp : cmp;
    });
    const sliced = filtered.slice(page * pageSize, (page + 1) * pageSize);
    return {
      patterns: sliced,
      page,
      page_size: pageSize,
      total_count: filtered.length
    };
  };

  return [
    async request => {
      const pathname = getPathname(request);
      const method = request.method();
      const url = new URL(request.url());

      // GET catalog lists
      if (
        method === "GET" &&
        (pathname === "/api/catalog/content" ||
          pathname === "/api/catalog/content/pattern" ||
          pathname === "/api/content/patterns" ||
          pathname === "/api/content/catalog/patterns")
      ) {
        return jsonResponse(paginate(patterns, url));
      }

      // Author profile lookup — /api/identity/users/profile/:id
      if (
        method === "GET" &&
        pathname.match(/^\/api\/identity\/users\/profile\/[^/]+$/)
      ) {
        const id = lastPathSegment(pathname);
        const author = authors.find(a => a.id === id);
        if (author) {
          return jsonResponse(author);
        }
        return jsonResponse({}, 200);
      }

      // POST /api/content/catalog/unpublish or /api/catalog/unpublish
      if (
        method === "POST" &&
        (pathname === "/api/content/catalog/unpublish" ||
          pathname === "/api/catalog/unpublish" ||
          pathname === "/api/content/unpublish")
      ) {
        let body: Record<string, unknown> = {};
        try {
          body = JSON.parse(request.postData() ?? "{}") as Record<string, unknown>;
        } catch {
          // ignore
        }
        const id = body.id ?? body.pattern_id;
        patterns = patterns.map(p => (p.id === id ? { ...p, visibility: "private" } : p));
        return jsonResponse({ success: true });
      }

      // GET catalog leaderboard (used by the performers section inside catalog)
      if (method === "GET" && pathname === "/api/catalog/leaderboard") {
        return jsonResponse({ leaderboard: [], total_count: 0 });
      }

      return undefined;
    }
  ];
}

// -----------------------------------------------------------------------------
// Multi-org shared shell: lists several organizations, and supports the
// "All Organizations" virtual selector ({ id: "all", name: "All Organizations" }).
// Used by the tenancy spec to drive org switching and provider-admin flows.
// -----------------------------------------------------------------------------

export function createMultiOrgSharedShellHandlers(options: {
  user?: Record<string, unknown>;
  organizations: Array<Record<string, unknown>>;
}): ApiHandler[] {
  const user = { roleNames: [] as string[], ...(options.user ?? {}) };
  const organizations = options.organizations;

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      if (pathname === "/api/identity/users/profile") {
        return jsonResponse(user);
      }

      if (pathname === "/api/identity/orgs/by-domain") {
        return jsonResponse(null);
      }

      if (pathname === "/api/identity/orgs") {
        return jsonResponse({ organizations });
      }

      // Per-org lookups — match ONLY the single-org path
      // `/api/identity/orgs/:id`. Deeper subpaths like `.../users/keys` or
      // `.../roles` must fall through to their dedicated handlers.
      if (method === "GET" && isSingleOrgLookup(pathname)) {
        const orgId = lastPathSegment(pathname);
        const found = organizations.find(o => o.id === orgId);
        if (found) {
          return jsonResponse({ organizations: [found] });
        }
        return undefined;
      }

      return undefined;
    }
  ];
}

// -----------------------------------------------------------------------------
// User-management handlers — the org users table plus the two lookups behind
// the "Edit" action.
//
// `getUsersByEmail` is not a distinct endpoint: it is the same
// `GET /api/identity/orgs/:orgId/users` route driven with `?search=<email>`
// (see `api/users.ts::useLazyGetUsersByEmailQuery`). Because it is a *search*,
// one email can legitimately match several rows, which is exactly why the page
// must select by exact `userId` rather than taking the first row. This helper
// therefore answers the search the way the server does — every user whose
// email contains the search term — so a spec can reproduce that.
//
// `requestLog` records every lookup so a spec can assert a route or effect did
// not enter a re-request loop.
// -----------------------------------------------------------------------------

/**
 * Trailing segments of `/api/identity/users/profile/*` that are shell
 * endpoints rather than a user id.
 */
const SHELL_PROFILE_SUBROUTES = ["details", "provider"];

export function createUserManagementHandlers(options?: {
  users?: Array<Record<string, unknown>>;
  orgId?: string;
  requestLog?: string[];
}): ApiHandler[] {
  const users = options?.users ?? [];
  const orgId = options?.orgId ?? "org-1";
  const requestLog = options?.requestLog;

  const usersEnvelope = (rows: Array<Record<string, unknown>>) => ({
    data: rows,
    page: 0,
    pageSize: 10,
    totalCount: rows.length
  });

  return [
    request => {
      const pathname = getPathname(request);
      const method = request.method();

      // GET /api/identity/users/profile/:id — resolves a `?profile=<userId>`
      // deep link to the email the table lookup is keyed on.
      //
      // `/details` and `/provider` are shell bootstrap subroutes served by
      // `createAuthenticatedShellHandlers`, NOT user ids. Matching them here
      // would shadow that helper (this one is installed first) and answer the
      // shell with a 404.
      if (
        method === "GET" &&
        pathname.startsWith("/api/identity/users/profile/") &&
        !SHELL_PROFILE_SUBROUTES.includes(lastPathSegment(pathname) ?? "")
      ) {
        const id = lastPathSegment(pathname);
        requestLog?.push(`profile:${id}`);
        const user = users.find(u => u.userId === id || u.id === id);
        if (!user) {
          return jsonResponse({ error: "user not found" }, 404);
        }
        return jsonResponse(user);
      }

      // GET /api/identity/orgs/:orgId/users — the table, and the email search
      // that backs the Edit action. The deep-link path deliberately searches
      // with `orgId: "all"`, so match any org segment rather than just the
      // current one.
      if (
        method === "GET" &&
        (pathname === `/api/identity/orgs/${orgId}/users` ||
          pathname === "/api/identity/orgs/all/users")
      ) {
        const search = new URL(request.url()).searchParams.get("search") ?? "";
        if (!search) {
          requestLog?.push("list");
          return jsonResponse(usersEnvelope(users));
        }
        requestLog?.push(`search:${search}`);
        const matches = users.filter(u =>
          String(u.email ?? "")
            .toLowerCase()
            .includes(search.toLowerCase())
        );
        return jsonResponse(usersEnvelope(matches));
      }

      return undefined;
    }
  ];
}
