import { Keys } from "@meshery/schemas/permissions";
import { expect, test, type Page } from "@playwright/test";
import {
  createAuthenticatedShellHandlers,
  createFallbackHandlers,
  createInvitationsHandlers,
  createSharedShellHandlers,
  mockApi
} from "./helpers/network";

const manageInvitationsKey = {
  id: Keys.IdentityAccessManagementManageInvitations.id,
  function: Keys.IdentityAccessManagementManageInvitations.function
};

/**
 * TP-016 Invitation flow coverage. The invitations management page lists,
 * creates, edits, and deletes organization invitations through the
 * `/api/organizations/invitations*` RTK Query surface.
 */

const authenticatedUser = {
  id: "user-1",
  first_name: "Test",
  last_name: "User",
  email: "test@example.com",
  preferences: { selectedOrg: "org-1" }
};

const organization = {
  id: "org-1",
  name: "Test Organization",
  domain: "localhost:3000"
};

const existingInvitation = {
  id: "invite-1",
  owner: "user-1",
  name: "Engineering Team Invite",
  description: "Open seats for backend engineers",
  emails: ["engineer@example.com"],
  status: "enabled",
  orgId: "org-1",
  quota: 5,
  acceptedBy: [],
  roles: [],
  teams: [],
  createdAt: "2026-01-01T00:00:00Z",
  updatedAt: "2026-01-01T00:00:00Z",
  deletedAt: ""
};

/**
 * A field in the invitation RJSF form, addressed by its schema property.
 *
 * NOT `getByLabel`. Playwright resolves that from the `<label>` element's raw
 * text content, and RJSF appends the required marker, so an anchored
 * `getByLabel(/^Name$/i)` can never match - which is why the three fills using
 * it had been timing out for their full 60s on both master and this branch.
 *
 * `root_<property>` is RJSF's own id scheme: stable across label, casing and
 * required-marker changes, and it names the schema property the handler
 * actually reads, which is the thing worth pinning here (see
 * docs/contracts/form-schema-source-of-truth.md).
 *
 * The labels themselves are asserted separately by `expectHumanFieldLabels`
 * below. On master these render as the raw property names, because the form's
 * ui schema supplied `ui:label` (a BOOLEAN - "render the label at all") where
 * `ui:title` supplies the text. This branch fixes that, so the id locator is
 * deliberately paired with a label assertion: the ids alone would not notice
 * the titles regressing.
 */
const invitationField = (page: Page, property: string) =>
  page.getByRole("dialog").locator(`#root_${property}`);

/**
 * Guards the `ui:title` fix: the fields must expose human labels, not the raw
 * schema property names. Role locators are used because their accessible-name
 * computation ignores the required marker, which carries `aria-hidden`.
 */
const expectHumanFieldLabels = async (page: Page) => {
  await expect(
    page.getByRole("dialog").getByRole("textbox", { name: "Name", exact: true })
  ).toBeVisible();
  await expect(
    page.getByRole("dialog").getByRole("textbox", { name: "Description", exact: true })
  ).toBeVisible();
};

test.describe("invitations flow", () => {
  test("shows empty state and create action when no invitations exist", async ({
    page
  }) => {
    await mockApi(page, [
      ...createSharedShellHandlers({
        user: authenticatedUser,
        organizations: [organization]
      }),
      ...createAuthenticatedShellHandlers({
        orgId: "org-1",
        keys: [manageInvitationsKey]
      }),
      ...createInvitationsHandlers({ invitations: [] }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/identity/invitations");

    await expect(
      page.getByRole("button", { name: /Create New Invitation/i })
    ).toBeVisible();
    await expect(page.getByText("No Invitations Found").first()).toBeVisible();
  });

  const invitationHandlers = () => [
    ...createSharedShellHandlers({
      user: authenticatedUser,
      organizations: [organization]
    }),
    ...createAuthenticatedShellHandlers({
      orgId: "org-1",
      keys: [manageInvitationsKey]
    }),
    ...createInvitationsHandlers({ invitations: [existingInvitation] }),
    ...createFallbackHandlers()
  ];

  test("supports list, create, and delete invitation flows", async ({ page }) => {
    const createdInvitationName = "Platform Team Invite";

    await mockApi(page, invitationHandlers());
    await page.goto("/identity/invitations");

    await expect(
      page.getByRole("row", { name: new RegExp(existingInvitation.name) })
    ).toBeVisible();

    await page.getByRole("button", { name: /Create New Invitation/i }).click();
    await expect(
      page.getByRole("dialog").getByText("Create New Invitation")
    ).toBeVisible();
    await expectHumanFieldLabels(page);
    await invitationField(page, "name").fill(createdInvitationName);
    await invitationField(page, "description").fill(
      "Invite for the platform engineering team"
    );
    await invitationField(page, "quota").fill("3");
    await page.getByRole("button", { name: "Create Invitation" }).click();

    const createdInvitationRow = page.getByRole("row", {
      name: new RegExp(createdInvitationName)
    });
    await expect(createdInvitationRow).toBeVisible();

    await createdInvitationRow.getByTitle("Delete Invitation").click();

    await expect(
      page.getByRole("row", { name: new RegExp(createdInvitationName) })
    ).toHaveCount(0);
    await expect(
      page.getByRole("row", { name: new RegExp(existingInvitation.name) })
    ).toBeVisible();
  });

  // EXPECTED TO FAIL - a live product defect, not a harness one:
  // https://github.com/layer5io/meshery-cloud/issues/5969
  //
  // `test.fail()` rather than `test.skip()` deliberately: the test still RUNS
  // and still reports, and the run goes RED the moment the defect is fixed,
  // which forces this annotation to be removed rather than outliving the bug. A
  // skip would be indistinguishable from a pass, which is the failure mode this
  // whole branch exists to remove.
  //
  // Measured: opening Edit Invitation, changing `root_name` and clicking
  // "Update Invitation" issues NO PUT at all (only the analytics beacon). The
  // dialog stays open and RJSF renders no validation message, so nothing on
  // screen tells the user why their edit did not save. That is the documented
  // dead-Save-button shape - RJSF refuses a submit naming a required property it
  // is not rendering - the same class as #5916 (Create/Edit Workspace) and #5917
  // (badge modal); see AGENTS.md "Schema-Driven Development" and
  // docs/contracts/form-schema-source-of-truth.md. Filling `emails` first does
  // not unblock it, so the missing required property is something else and
  // finding it needs the modal's schema/uiSchema pair read against the
  // construct, which is out of scope here.
  test("updates an existing invitation", async ({ page }) => {
    // Pinned as an expected failure by #5991, because the form rendered its
    // fields with the raw schema property names: its ui schema supplied
    // `ui:label` (a BOOLEAN - "render the label at all") where `ui:title`
    // supplies the text, so the Edit dialog had no reachable "Name" field.
    //
    // UNPINNED here because this branch fixes that cause (#6001): the ui schema
    // now supplies `ui:title` for every field. Verified locally against a real
    // static export - with the pin still in place Playwright reported
    // "Expected to fail, but passed", which is itself a failure, so leaving it
    // would have turned the PR red for a reason absent from the diff.
    //
    // If you ever re-pin a case here, put `test.fail()` inside the body: in the
    // describe scope it is a modifier on the whole SUITE and silently marks the
    // passing siblings as expected-failures too.
    const updatedInvitationName = "Platform Admin Invite";

    await mockApi(page, invitationHandlers());
    await page.goto("/identity/invitations");

    const existingInvitationRow = page.getByRole("row", {
      name: new RegExp(existingInvitation.name)
    });
    await expect(existingInvitationRow).toBeVisible();
    await existingInvitationRow.getByTitle("Edit Invitation").click();

    await expect(page.getByRole("dialog").getByText("Edit Invitation")).toBeVisible();
    await invitationField(page, "name").fill(updatedInvitationName);
    await invitationField(page, "description").fill(
      "Updated invite for platform administrators"
    );
    await page.getByRole("button", { name: "Update Invitation" }).click();

    await expect(
      page.getByRole("row", { name: new RegExp(updatedInvitationName) })
    ).toBeVisible();
  });
});
