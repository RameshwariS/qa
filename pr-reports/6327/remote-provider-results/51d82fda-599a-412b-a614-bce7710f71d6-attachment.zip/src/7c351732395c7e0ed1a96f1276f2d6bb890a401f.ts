import { expect, test } from "@playwright/test";
import {
  createAcademyInstructorConsoleHandlers,
  createAuthenticatedShellHandlers,
  createDashboardHandlers,
  createFallbackHandlers,
  createPermissionKeysHandler,
  createSharedShellHandlers,
  mockApi
} from "./helpers/network";

const authenticatedUser = {
  id: "user-1",
  first_name: "Test",
  last_name: "User",
  email: "test@example.com",
  preferences: { selectedOrg: "org-1" }
};

const organization = {
  id: "org-1",
  name: "Test Organization",
  domain: "localhost:3000"
};

// The dashboard opens its "Where do you want to start?" journey modal unless
// the profile says otherwise, and that dialog covers the grid.
const userWithoutWelcomeModal = {
  ...authenticatedUser,
  preferences: {
    ...authenticatedUser.preferences,
    remoteProviderPreferences: { showWelcomeModal: false }
  }
};

// The action buttons are wrapped in a tooltip that takes over the accessible
// name on hover, so match on rendered text rather than on the role name.
const actionButton = (page: import("@playwright/test").Page, label: string) =>
  page.locator("button").filter({ hasText: new RegExp(`^${label}$`) });

// PUT /api/identity/orgs/:orgId is how the layout is persisted.
const isLayoutSave = (request: import("@playwright/test").Request) =>
  request.method() === "PUT" &&
  new URL(request.url()).pathname === "/api/identity/orgs/org-1";

const layoutSaveHandler =
  (saveStatus: number) => (request: import("@playwright/test").Request) =>
    isLayoutSave(request)
      ? {
          status: saveStatus,
          contentType: "application/json",
          body:
            saveStatus >= 400
              ? { error: "could not persist organization preferences" }
              : { id: "org-1", name: "Test Organization" }
        }
      : undefined;

// The shell every edit-capable dashboard case runs in, kept in ONE place because
// its order is the contract: the first handler to answer wins. `extraHandlers`
// go first so a case's own verdict is the one under test, and the granted keys
// go before the shell helper, whose default empty-keys handler would otherwise
// answer first and hide the Edit button.
const openDashboard = async (
  page: import("@playwright/test").Page,
  extraHandlers: Parameters<typeof mockApi>[1] = []
) => {
  await mockApi(page, [
    ...extraHandlers,
    ...createPermissionKeysHandler(["EDIT_ORGANIZATION", "VIEW_ORGANIZATIONS"]),
    ...createSharedShellHandlers({
      user: userWithoutWelcomeModal,
      organizations: [organization]
    }),
    ...createAuthenticatedShellHandlers({ orgId: "org-1", skipKeys: true }),
    ...createDashboardHandlers({ orgId: "org-1" }),
    ...createFallbackHandlers()
  ]);

  await page.goto("/dashboard", { waitUntil: "domcontentloaded" });
  await expect(page).toHaveTitle(/Dashboard/);
};

test.describe("dashboard route", () => {
  test("renders the dashboard page with correct title", async ({ page }) => {
    await mockApi(page, [
      ...createSharedShellHandlers({
        user: authenticatedUser,
        organizations: [organization]
      }),
      ...createAuthenticatedShellHandlers({ orgId: "org-1" }),
      ...createDashboardHandlers({ orgId: "org-1" }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/dashboard", { waitUntil: "domcontentloaded" });

    await expect(page).toHaveTitle(/Dashboard/);
  });

  test("shows the organization name in the layout", async ({ page }) => {
    await mockApi(page, [
      ...createSharedShellHandlers({
        user: authenticatedUser,
        organizations: [organization]
      }),
      ...createAuthenticatedShellHandlers({ orgId: "org-1" }),
      ...createDashboardHandlers({ orgId: "org-1" }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/dashboard", { waitUntil: "domcontentloaded" });

    // The organization name appears in the navbar switcher plus any
    // shell-level indicator, so `.first()` sidesteps strict mode.
    await expect(page.getByText("Test Organization").first()).toBeVisible();
  });

  test("renders dashboard widget area", async ({ page }) => {
    await mockApi(page, [
      ...createSharedShellHandlers({
        user: authenticatedUser,
        organizations: [organization]
      }),
      ...createAuthenticatedShellHandlers({ orgId: "org-1" }),
      ...createDashboardHandlers({
        orgId: "org-1",
        preferences: {
          dashboard: {
            layout: {
              lg: []
            }
          }
        }
      }),
      ...createFallbackHandlers()
    ]);

    await page.goto("/dashboard", { waitUntil: "domcontentloaded" });

    await expect(page).toHaveTitle(/Dashboard/);
  });
});

// The registration donut renders differently inside a dashboard cell than on
// the wide Instructor Console page: the rich per-status legend and the centre
// total give way to recharts' own compact legend, which draws inside the
// chart's height. That trade only holds if the compact legend actually FITS -
// and the mocked-recharts Jest suite cannot tell, because there Legend, Pie
// and ResponsiveContainer are plain divs with no layout. This asserts the
// real geometry in a real browser.
test.describe("academy registrations widget in a dashboard cell", () => {
  // `lg` needs a grid container wider than 1200px. The default 1280px viewport
  // puts it in `md` once the nav rail is subtracted, which is a different (and
  // wider, in columns) cell than the w:3 quarter the widget ships with.
  test.use({ viewport: { width: 1600, height: 1000 } });

  // Every value of public.academy_registration_status, all non-zero. Five is
  // the most entries the colour map now permits, and the case a horizontal
  // legend cannot fit on one row in a quarter-width cell.
  const fiveStatusSummary = {
    orgConfig: { version: "v1.0.0", module: "academy.layer5.io" },
    totalLearners: 120,
    totalActiveLearners: 45,
    curricula: [],
    registrationsSummary: [
      { status: "registered", totalCount: 40 },
      { status: "in_progress", totalCount: 30 },
      { status: "completed", totalCount: 20 },
      { status: "failed", totalCount: 10 },
      { status: "withdrawn", totalCount: 5 }
    ],
    testsSummary: { totalAttempts: 0, totalPassed: 0, totalFailed: 0 },
    tests: [],
    curriculaList: { total: 0, data: [] }
  };

  // The widget at its shipped defaultSizing. Every breakpoint carries it so the
  // spec still renders it if the grid resolves to something other than `lg`.
  const registrationsChartLayout = () => {
    const item = {
      h: 5,
      i: "ACADEMY_REGISTRATIONS_CHART",
      moved: false,
      static: false,
      w: 3,
      x: 0,
      y: 0
    };

    return {
      dashboard: {
        layout: { lg: [item], md: [item], sm: [item], xs: [item], xxs: [item] }
      }
    };
  };

  test("fits its compact legend without clipping, overlap or overflow", async ({
    page
  }, testInfo) => {
    await mockApi(page, [
      ...createSharedShellHandlers({
        user: userWithoutWelcomeModal,
        organizations: [organization]
      }),
      // Before the shell helper, whose default empty-keys handler would
      // otherwise answer first and disable the widget entirely.
      ...createPermissionKeysHandler(["VIEW_ACADEMY", "VIEW_ACADEMY_METRICS"]),
      // The layout rides on THIS helper, not on createDashboardHandlers: both
      // answer GET /orgs/:orgId/preferences and the first handler to respond
      // wins, so a layout passed to the later one is silently shadowed and the
      // grid renders DEFAULT_LAYOUT instead.
      ...createAuthenticatedShellHandlers({
        orgId: "org-1",
        skipKeys: true,
        preferences: registrationsChartLayout()
      }),
      // Before the fallback helper, or the academy summary is shadowed and
      // this silently asserts against an empty payload.
      ...createAcademyInstructorConsoleHandlers({ summary: fiveStatusSummary }),
      ...createDashboardHandlers({ orgId: "org-1" }),
      ...createFallbackHandlers()
    ]);

    // recharts' Pie defaults to isAnimationActive "auto", which resolves to
    // `!prefers-reduced-motion`, and it interpolates the sector ANGLES - so
    // during the sweep `.recharts-pie` is a thin arc that grows into the ring.
    // Honouring reduced motion renders the final geometry immediately.
    await page.emulateMedia({ reducedMotion: "reduce" });

    // The dev server compiles routes on demand, so warm the route before
    // measuring: a cold first paint can outlast the per-test timeout.
    await page.goto("/dashboard", { waitUntil: "domcontentloaded" });
    await expect(page).toHaveTitle(/Dashboard/);

    const card = page.locator(".metrics-card").first();
    await expect(card).toBeVisible();

    const legendItems = card.locator(".recharts-legend-item");
    await expect(legendItems).toHaveCount(5);
    await expect(card.locator(".recharts-pie")).toBeVisible();

    // Then wait for the layout to SETTLE rather than for a duration. A fixed
    // sleep is a race whose safety depends on recharts' current animation
    // defaults; this holds whatever a future version does, and costs one poll
    // interval once reduced motion has already stilled the chart.
    await card.evaluate(
      el =>
        new Promise<void>(resolve => {
          const sample = () =>
            [
              el.querySelector(".recharts-pie"),
              el.querySelector(".recharts-legend-wrapper")
            ]
              .map(node => {
                const box = (node as Element).getBoundingClientRect();
                return `${box.top}:${box.left}:${box.width}:${box.height}`;
              })
              .join("|");

          let previous = sample();
          let stable = 0;

          const timer = setInterval(() => {
            const current = sample();
            stable = current === previous ? stable + 1 : 0;
            previous = current;

            if (stable >= 2) {
              clearInterval(timer);
              resolve();
            }
          }, 100);
        })
    );

    const geometry = await card.evaluate(el => {
      const content = el.querySelector(".MuiCardContent-root") as HTMLElement;
      const pie = el.querySelector(".recharts-pie") as SVGGElement;
      const legendWrapper = el.querySelector(".recharts-legend-wrapper") as HTMLElement;
      const contentBox = content.getBoundingClientRect();
      const pieBox = pie.getBoundingClientRect();
      const legendBox = legendWrapper.getBoundingClientRect();

      return {
        content: {
          top: contentBox.top,
          bottom: contentBox.bottom,
          left: contentBox.left,
          right: contentBox.right,
          scrollOverflow: content.scrollHeight - content.clientHeight
        },
        pie: { bottom: pieBox.bottom, height: pieBox.height, width: pieBox.width },
        legend: { top: legendBox.top },
        entries: [...el.querySelectorAll(".recharts-legend-item")].map(item => {
          const box = item.getBoundingClientRect();
          return {
            label: (item.textContent || "").trim(),
            top: box.top,
            bottom: box.bottom,
            left: box.left,
            right: box.right
          };
        })
      };
    });

    // Every status is labelled, and each label is inside the card's content
    // box on all four sides - a wrapped row spilling past the bottom is the
    // failure a fixed legend height produced.
    expect(geometry.entries.map(entry => entry.label).sort()).toEqual([
      "Completed",
      "Failed",
      "In Progress",
      "Registered",
      "Withdrawn"
    ]);

    for (const entry of geometry.entries) {
      expect(entry.top).toBeGreaterThanOrEqual(geometry.content.top - 1);
      expect(entry.bottom).toBeLessThanOrEqual(geometry.content.bottom + 1);
      expect(entry.left).toBeGreaterThanOrEqual(geometry.content.left - 1);
      expect(entry.right).toBeLessThanOrEqual(geometry.content.right + 1);
    }

    // The legend sits below the donut rather than on top of it.
    expect(geometry.legend.top).toBeGreaterThanOrEqual(geometry.pie.bottom - 1);

    // And the donut keeps a usable size once the legend has taken its share.
    expect(geometry.pie.height).toBeGreaterThan(120);
    expect(geometry.pie.width).toBeGreaterThan(120);

    // Nothing was pushed into an internal scroll to make the above true.
    expect(geometry.content.scrollOverflow).toBeLessThanOrEqual(1);

    await page.screenshot({
      path: testInfo.outputPath("academy-registrations-dashboard-cell.png")
    });
  });
});

// The dashboard's page framing. Sistent's `DashboardLayout` deliberately owns
// no page chrome - its root is `width: 100%` with no maxWidth and its content
// slot is `padding: 0` - so the cap, the centring and the side gutters all come
// from the one `<Container maxWidth="xl">` that wraps BOTH the action row and
// the grid (components/dashboard/index.tsx).
//
// Both halves of that contract are invisible to every other gate: a build,
// `tsc` and the Jest suite all stay green with the grid running edge-to-edge
// past the navbar, or with the action row inset by a `px` the grid beneath it
// does not share. Only real geometry in a real browser can tell.
test.describe("dashboard page framing", () => {
  // The Edit button is what the action row is measured from.
  const openFramedDashboard = async (page: import("@playwright/test").Page) => {
    await openDashboard(page);
    await expect(page.getByRole("button", { name: "Edit" })).toBeVisible();
    await expect(page.locator(".react-grid-layout")).toBeVisible();
  };

  // The action row's own padding is subtracted, so the comparison is between
  // the two elements' CONTENT edges. Re-adding a `px` to the row (the shape
  // this framing replaced) therefore fails this spec rather than passing it.
  // The row is located through one of its own buttons, so the anchor has to be a
  // button that is actually shown in the mode under test: `Edit` is `START_EDIT`,
  // whose `isShown` is `!isEditMode`, so it is absent the moment edit mode opens.
  const framingGeometry = (page: import("@playwright/test").Page, anchorLabel = "Edit") =>
    page.evaluate(label => {
      const anchorButton = Array.from(document.querySelectorAll("button")).find(
        button => (button.textContent || "").trim() === label
      );
      const actionRow = anchorButton?.closest("div.MuiStack-root") as HTMLElement | null;
      const grid = document.querySelector(".react-grid-layout") as HTMLElement | null;

      if (!actionRow || !grid) {
        throw new Error(
          `dashboard action row (anchored on the "${label}" button) or widget grid not found`
        );
      }

      // The navbar's own Container, measured on its CONTENT edges like the row.
      const navbarContainer = document.querySelector(
        "header.MuiAppBar-root .MuiContainer-root"
      ) as HTMLElement | null;

      if (!navbarContainer) {
        throw new Error("navbar Container not found");
      }

      const rowRect = actionRow.getBoundingClientRect();
      const rowStyle = window.getComputedStyle(actionRow);
      const gridRect = grid.getBoundingClientRect();
      const navbarRect = navbarContainer.getBoundingClientRect();
      const navbarStyle = window.getComputedStyle(navbarContainer);

      // Per control, the two things a squeezed row does to it: its own content
      // stops fitting, and its label breaks onto extra line boxes. A `Range`
      // over the label's text node yields one rect per line, so the line count
      // is the browser's own answer rather than anything computed here.
      const actionButtons = Array.from(actionRow.querySelectorAll("button")).map(
        button => {
          const buttonLabel = (button.textContent || "").trim();
          const textNode = Array.from(button.childNodes).find(
            node => node.nodeType === Node.TEXT_NODE && (node.textContent || "").trim()
          );

          if (!textNode) {
            throw new Error(
              `dashboard action row button "${buttonLabel}" has no text label to measure`
            );
          }

          const labelRange = document.createRange();
          labelRange.selectNodeContents(textNode);

          return {
            label: buttonLabel,
            contentOverflow: button.scrollWidth - button.clientWidth,
            lineCount: labelRange.getClientRects().length
          };
        }
      );

      return {
        viewportWidth: window.innerWidth,
        actionButtons,
        actionRow: {
          left: rowRect.left + parseFloat(rowStyle.paddingLeft),
          right: rowRect.right - parseFloat(rowStyle.paddingRight)
        },
        grid: { left: gridRect.left, right: gridRect.right, width: gridRect.width },
        navbar: {
          left: navbarRect.left + parseFloat(navbarStyle.paddingLeft),
          right: navbarRect.right - parseFloat(navbarStyle.paddingRight)
        },
        documentScrollOverflow:
          document.documentElement.scrollWidth - document.documentElement.clientWidth
      };
    }, anchorLabel);

  test("caps and centres the dashboard beyond the xl breakpoint", async ({ page }) => {
    // Comfortably past `xl` (1536px), so a missing cap is unmistakable rather
    // than a few pixels of rounding.
    await page.setViewportSize({ width: 2200, height: 1200 });
    await openFramedDashboard(page);

    const { viewportWidth, grid } = await framingGeometry(page);

    // Capped: the grid stops at the xl breakpoint, not at the viewport.
    expect(grid.width).toBeLessThanOrEqual(1536);
    expect(grid.width).toBeLessThan(viewportWidth - 100);

    // And centred: equal space either side.
    expect(Math.abs(grid.left - (viewportWidth - grid.right))).toBeLessThanOrEqual(1);
  });

  for (const viewport of [
    { name: "beyond xl", width: 2200, height: 1200 },
    { name: "desktop", width: 1440, height: 900 },
    { name: "mobile", width: 480, height: 900 }
  ]) {
    test(`action row, widget grid and navbar share one left and right edge (${viewport.name})`, async ({
      page
    }) => {
      await page.setViewportSize({ width: viewport.width, height: viewport.height });
      await openFramedDashboard(page);

      const { actionRow, grid, navbar } = await framingGeometry(page);

      expect(Math.abs(actionRow.left - grid.left)).toBeLessThanOrEqual(1);
      expect(Math.abs(actionRow.right - grid.right)).toBeLessThanOrEqual(1);

      // The navbar is framed by an `xl` Container too, so the page shares its
      // edges. Measured rather than read from source: `NavbarContainer`'s
      // `styled(Container)` `maxWidth: "100%"` looks like it uncaps the navbar,
      // but MUI emits the `xl` cap as a later `@media` rule that wins at and
      // above `xl` - a reading that was once documented backwards.
      expect(Math.abs(navbar.left - grid.left)).toBeLessThanOrEqual(1);
      expect(Math.abs(navbar.right - grid.right)).toBeLessThanOrEqual(1);

      // Gutters, not a zero-width inset: content is held off the viewport edge.
      expect(grid.left).toBeGreaterThan(0);

      // And the framing settles without leaving a horizontal page scroll.
      // Polled rather than read once: `measureBeforeMount={false}` lets
      // react-grid-layout paint one frame at WidthProvider's default 1280px
      // before it measures the real container, so a narrow viewport transiently
      // renders cells wider than the page on first paint (true on master too -
      // it is the grid's mount behaviour, not this framing). A genuine framing
      // overflow never settles, so this still fails red for one.
      await expect
        .poll(async () => (await framingGeometry(page)).documentScrollOverflow)
        .toBeLessThanOrEqual(1);
    });
  }

  // The three cases above only ever measure VIEW mode - `openFramedDashboard`
  // stops at the `Edit` button - so the action row is never seen carrying the extra
  // controls edit mode gives it.
  //
  // What a non-wrapping row does at that width is NOT push the page wider: the
  // buttons are shrinkable flex items, so the browser absorbs the shortfall by
  // squeezing each of them toward MUI's 64px `min-width` floor while the
  // document keeps its exact viewport width. The damage therefore has to be
  // measured on the CONTROLS. Two symptoms, because neither alone covers every
  // control: a button whose content no longer fits reports the overflow, but one
  // that shrank to exactly its longest word reports none while its label sits on
  // three lines. Nothing else looks - the picker and reopen specs run at desktop
  // width, and none of this reaches `tsc`, `next build` or Jest.
  test("edit-mode action row keeps every control uncrushed at a narrow viewport", async ({
    page
  }) => {
    await page.setViewportSize({ width: 480, height: 900 });
    await openFramedDashboard(page);

    await actionButton(page, "Edit").click();

    // FOUR controls here, because this case enters edit mode AT this width:
    // below `md` the picker is Sistent's bottom sheet and its header row -
    // title and close control - is hidden, so nothing clears `isPickerOpen` and
    // `ADD_WIDGETS` (`isEditMode && !isPickerOpen`) does not render. A session
    // that closed the picker at `md` and up and then narrowed would show it as
    // a fifth control; this case does not cover that. Four is already enough to
    // crush: the row could not wrap before `flexWrap`, and four controls
    // overflow it on master.
    //
    // Deliberately NOT reached by clicking the picker's X: that control does
    // not exist at this width, so a test that clicked it would be asserting
    // against a state the product cannot be in.

    // Asserted before the geometry, so a future change that silently drops a
    // control cannot make the overflow check pass by shortening the row.
    for (const label of ["Cancel", "Save", "Save and Close", "Reset"]) {
      await expect(actionButton(page, label)).toBeVisible();
    }
    await expect(actionButton(page, "Add Widgets")).toHaveCount(0);

    // Anchored on `Cancel`, not `Edit`: `START_EDIT` is unmounted here.
    // Polled for the same reason as the view-mode cases above - the grid's first
    // paint at WidthProvider's default width transiently overflows a narrow
    // viewport on master too, while a real framing overflow never settles.
    await expect
      .poll(async () => (await framingGeometry(page, "Cancel")).documentScrollOverflow)
      .toBeLessThanOrEqual(1);

    const { actionButtons } = await framingGeometry(page, "Cancel");

    // The helper reads the row the browser rendered, so this also proves the
    // four asserted above are the four it measured.
    expect(actionButtons.map(button => button.label)).toEqual([
      "Cancel",
      "Save",
      "Save and Close",
      "Reset"
    ]);

    // Named rather than counted, so a failure says WHICH controls were crushed.
    expect(
      actionButtons.filter(button => button.contentOverflow > 1).map(b => b.label)
    ).toEqual([]);
    expect(
      actionButtons.filter(button => button.lineCount > 1).map(b => b.label)
    ).toEqual([]);
  });
});

// The widget picker is `position: sticky` under the navbar. Sistent sizes it
// from `sidebarHeight` (default `100vh`) INDEPENDENTLY of the `sidebarTopOffset`
// it is pinned at, so a caller that supplies an offset and not a height pushes
// the panel's bottom `sidebarTopOffset` worth of content below the viewport -
// permanently, because a sticky element does not scroll with the page. Nothing
// but real geometry can see it: the props type-check either way.
test.describe("dashboard widget picker panel", () => {
  // The sticky panel carries no class of its own; anchor on the picker's own
  // close control and walk up to the element actually doing the sticking. The
  // navbar's own bottom edge is MEASURED in the same pass: a spec that restates
  // the component's offset as a literal only re-asserts that the prop was
  // applied, and stays green at whatever value the component happens to hold -
  // which is how an offset 8px short of the opaque navbar shipped.
  const panelGeometry = (page: import("@playwright/test").Page) =>
    page.evaluate(() => {
      const closeButton = document.querySelector('[aria-label="Close widget picker"]');
      let node = closeButton?.parentElement ?? null;

      while (node && window.getComputedStyle(node).position !== "sticky") {
        node = node.parentElement;
      }

      if (!node) {
        throw new Error("sticky widget picker panel not found");
      }

      const navbar = document.querySelector("header.MuiAppBar-root");

      if (!navbar) {
        throw new Error("navbar app bar not found");
      }

      const rect = node.getBoundingClientRect();
      return {
        viewportHeight: window.innerHeight,
        navbarBottom: navbar.getBoundingClientRect().bottom,
        top: rect.top,
        bottom: rect.bottom,
        height: rect.height
      };
    });

  test("fits between the navbar and the bottom of the viewport", async ({ page }) => {
    // Above `md`, where Sistent renders the sticky side panel rather than the
    // mobile bottom sheet.
    await page.setViewportSize({ width: 1600, height: 1000 });

    await openDashboard(page);

    await actionButton(page, "Edit").click();
    await expect(page.locator('[aria-label="Close widget picker"]')).toBeVisible();

    const beforeScroll = await panelGeometry(page);

    // The contract, independent of where the page happens to be scrolled: the
    // panel is never taller than the space left under the navbar's measured
    // bottom edge. At the inherited `100vh` default this is exactly
    // `sidebarTopOffset` too tall.
    expect(beforeScroll.height).toBeLessThanOrEqual(
      beforeScroll.viewportHeight - beforeScroll.navbarBottom + 1
    );

    // And the consequence a user can see: once the panel is pinned it starts
    // exactly where the opaque navbar ends - too small an offset tucks the
    // panel's header underneath it, too large strands a gap - and its whole
    // height, the last widget card and the scroll container's own end, is
    // inside the viewport.
    await expect
      .poll(async () => {
        await page.evaluate(() =>
          window.scrollTo(0, document.documentElement.scrollHeight)
        );
        const { top, navbarBottom } = await panelGeometry(page);
        return Math.round(top - navbarBottom);
      })
      .toBe(0);

    const pinned = await panelGeometry(page);
    expect(Math.abs(pinned.top - pinned.navbarBottom)).toBeLessThanOrEqual(1);
    expect(pinned.height).toBeLessThanOrEqual(
      pinned.viewportHeight - pinned.navbarBottom + 1
    );
    expect(pinned.bottom).toBeLessThanOrEqual(pinned.viewportHeight + 1);
  });
});

// Edit mode must survive a failed save. `saveLayout` returns the mutation's
// verdict and both exit paths ("Save and Close", and saving on the way out of
// the unsaved-changes modal) are gated on it - before that, a 500 dropped the
// user back into view mode with the notification the only clue their layout had
// not been written, and the unsaved edits already discarded.
//
// Nothing else covers this: the gate is an `await` on an RTK Query result, so
// `tsc`, the build and the Jest suite are all green either way.
test.describe("dashboard layout save failure", () => {
  const openDashboardInEditMode = async (
    page: import("@playwright/test").Page,
    saveStatus: number
  ) => {
    await openDashboard(page, [layoutSaveHandler(saveStatus)]);

    await actionButton(page, "Edit").click();

    // Edit mode is on when the edit-only actions have replaced the Edit button.
    await expect(actionButton(page, "Save and Close")).toBeVisible();
    await expect(actionButton(page, "Edit")).toHaveCount(0);
  };

  test("keeps edit mode open when Save and Close fails", async ({ page }) => {
    await openDashboardInEditMode(page, 500);

    await actionButton(page, "Save and Close").click();

    // The failure is surfaced...
    await expect(page.getByText("failed to save layout")).toBeVisible();

    // ...and edit mode is still open, so the unsaved layout is still editable
    // and still savable. `Edit` reappearing here is the regression.
    await expect(actionButton(page, "Save and Close")).toBeVisible();
    await expect(actionButton(page, "Cancel")).toBeVisible();
    await expect(actionButton(page, "Edit")).toHaveCount(0);
  });

  // The positive control: without it the test above would still pass if the
  // button had simply stopped doing anything at all.
  test("closes edit mode when Save and Close succeeds", async ({ page }) => {
    await openDashboardInEditMode(page, 200);

    await actionButton(page, "Save and Close").click();

    await expect(page.getByText("Layout saved")).toBeVisible();
    await expect(actionButton(page, "Edit")).toBeVisible();
    await expect(actionButton(page, "Save and Close")).toHaveCount(0);
  });
});

// Closing the widget picker must not end the edit session. While panel
// visibility and session lifetime shared one flag, the picker's X set
// `isEditMode` false - which is the flag `useUnsavedChanges` arms both of its
// guards from - while leaving the edited layout in state and on screen. The
// result was a grid still showing changes that were no longer savable and no
// longer guarded: navigating away or reloading discarded them with no prompt.
//
// Nothing static can see this. The props type-check either way, and the loss
// only appears when a real navigation crosses a guard that has been disarmed.
test.describe("dashboard widget picker close control", () => {
  test("closes the panel only, leaving edit mode and its guards armed", async ({
    page
  }) => {
    await page.setViewportSize({ width: 1600, height: 1000 });

    await openDashboard(page);

    const gridItems = page.locator(".react-grid-item");
    await expect(gridItems.first()).toBeVisible();
    const initialWidgetCount = await gridItems.count();

    await actionButton(page, "Edit").click();
    await expect(page.locator('[aria-label="Close widget picker"]')).toBeVisible();

    // Change the layout by ADDING a widget from the picker, deliberately not by
    // removing one: `removeWidget` writes the layout through `_.set`, mutating
    // the object `savedLayout` also points at, so the unsaved-changes
    // comparison sees two equal layouts and the guard never arms - a real bug,
    // but someone else's (layer5io/meshery-cloud#6111). Adding spreads into
    // fresh arrays, so it is the path that actually exercises the guard.
    await page.locator('[aria-label^="Add "][aria-label$=" widget"]').first().click();
    await expect(gridItems).toHaveCount(initialWidgetCount + 1);

    await page.locator('[aria-label="Close widget picker"]').click();

    // The panel is gone...
    await expect(page.locator('[aria-label="Close widget picker"]')).toHaveCount(0);

    // ...but the session is not: the edit survives on screen, and every action
    // that can still act on it is present. `Edit` reappearing here is the
    // regression - it would mean the session ended with the edit stranded.
    await expect(gridItems).toHaveCount(initialWidgetCount + 1);
    await expect(actionButton(page, "Save")).toBeVisible();
    await expect(actionButton(page, "Save and Close")).toBeVisible();
    await expect(actionButton(page, "Cancel")).toBeVisible();
    await expect(actionButton(page, "Edit")).toHaveCount(0);

    // And the guard is still armed. Driven through a real in-app navigation
    // (the navbar logo is a Next `Link`, so it raises `routeChangeStart`)
    // rather than by reading state: a disarmed guard lets the route through
    // and this modal never appears.
    await page.locator('header.MuiAppBar-root a[href="/"]').first().click();
    await expect(page.getByText("Unsaved dashboard layout changes")).toBeVisible();
    await expect(page).toHaveURL(/\/dashboard/);
  });
});

// Saving from the unsaved-changes modal must complete the navigation it
// confirms. The save is awaited, so the rest of the handler resumes from a
// network completion rather than from the click: the state update that ends the
// session renders later than the router emits `routeChangeStart`, and a guard
// that only learns it is disarmed from a render blocks its own confirmed
// navigation - the layout saves, the modal stays, the URL does not move.
//
// Nothing static can see this, and the close-control case above stops once the
// modal appears. Driven through a real in-app navigation that LEAVES the
// dashboard: the navbar logo targets `/`, which redirects an authenticated user
// straight back here, so it cannot tell a completed navigation from a blocked
// one.
test.describe("dashboard unsaved-changes save and navigate", () => {
  test("saves once and completes the navigation it confirmed", async ({ page }) => {
    await page.setViewportSize({ width: 1600, height: 1000 });

    const layoutSaves: string[] = [];
    page.on("request", request => {
      if (isLayoutSave(request)) {
        layoutSaves.push(request.url());
      }
    });

    await openDashboard(page, [layoutSaveHandler(200)]);

    const gridItems = page.locator(".react-grid-item");
    await expect(gridItems.first()).toBeVisible();
    const initialWidgetCount = await gridItems.count();

    await actionButton(page, "Edit").click();
    await expect(page.locator('[aria-label="Close widget picker"]')).toBeVisible();

    // ADDED rather than removed, for the reason recorded in the close-control
    // case: removal never arms the guard (layer5io/meshery-cloud#6111).
    await page.locator('[aria-label^="Add "][aria-label$=" widget"]').first().click();
    await expect(gridItems).toHaveCount(initialWidgetCount + 1);

    await page.getByTestId("nav-menu-toggle").click();
    await page.getByTestId("nav-item-catalog").click();

    const unsavedModalTitle = page.getByText("Unsaved dashboard layout changes");
    await expect(unsavedModalTitle).toBeVisible();
    await expect(page).toHaveURL(/\/dashboard/);
    expect(layoutSaves).toHaveLength(0);

    await page.getByRole("button", { name: "Save Changes", exact: true }).click();

    await expect(page).toHaveURL(/\/catalog/);
    await expect(unsavedModalTitle).toHaveCount(0);
    expect(layoutSaves).toHaveLength(1);
  });
});

// Closing the picker must not be a one-way door. `DashboardLayout` renders the
// picker in exactly two branches - `isSidebarOpen && isMobile` (bottom sheet
// plus Sistent's own FAB) and `isSidebarOpen && !isMobile` (the sticky panel) -
// so with the flag false NEITHER renders, at every breakpoint, and above `md`
// Sistent ships no reopen affordance at all. Without the action row's own
// "Add Widgets" entry the session survives the X but can never reach the picker
// again: the only ways out are committing a half-built layout or discarding it.
//
// Driven at desktop width, where the sticky panel branch renders and Sistent's
// mobile FAB is therefore not present to mask the gap.
test.describe("dashboard widget picker reopen", () => {
  test("reopens the picker from the action row without cycling edit mode", async ({
    page
  }) => {
    await page.setViewportSize({ width: 1600, height: 1000 });

    await openDashboard(page);

    const picker = page.locator('[aria-label="Close widget picker"]');

    await actionButton(page, "Edit").click();

    // While the panel is open the reopen action is noise, so it must not render.
    await expect(picker).toBeVisible();
    await expect(actionButton(page, "Add Widgets")).toHaveCount(0);

    await picker.click();

    // The panel is gone, the session is not - and the way back is on screen.
    await expect(picker).toHaveCount(0);
    await expect(actionButton(page, "Add Widgets")).toBeVisible();
    await expect(actionButton(page, "Save")).toBeVisible();
    await expect(actionButton(page, "Save and Close")).toBeVisible();
    await expect(actionButton(page, "Cancel")).toBeVisible();
    await expect(actionButton(page, "Edit")).toHaveCount(0);

    await actionButton(page, "Add Widgets").click();

    // Back to the open state, with the reopen action retired again.
    await expect(picker).toBeVisible();
    await expect(actionButton(page, "Add Widgets")).toHaveCount(0);
    await expect(actionButton(page, "Edit")).toHaveCount(0);
  });
});

// A widget's cell height comes from its saved layout `h`, and nothing reconciles
// that against how tall the widget's content really is - which grows as the `xl`
// cap and narrower viewports make its text wrap. Every Sistent dashboard card is
// a `height: 100%` MUI Card, and a MUI Card is `overflow: hidden`, so a card
// pinned to its cell's height silently AMPUTATED whatever did not fit: in edit
// mode - where the delete/drag row pushed the card down and a `4rem` bottom
// padding caught the overflow - Help Center lost its last link and Getting
// Started lost part of `Start`, the one call to action a new user is meant to
// click. The contract now is: a cell's content that does not
// fit SCROLLS inside the cell's widget viewport; nothing clips it
// (components/dashboard/index.tsx).
//
// `tsc`, `next build` and Jest cannot see any of this, so it is pinned with real
// geometry: no clipping layer in a cell holds more than it shows, and the last
// thing a user needs in each of the two reported widgets can be scrolled fully
// into view inside its own cell. The scrolling viewport clips box-shadow too, so
// it is inset by the card elevation's reach; the spec measures the computed
// shadow against that room, in both modes.
test.describe("dashboard widgets never clip their own content", () => {
  // Every widget cell's clipping layers: the cell itself (view mode is
  // `overflow: hidden` so nothing escapes the grid) and each widget root inside
  // the viewport (a MUI Card is `overflow: hidden`). A layer whose content is
  // taller than its box is hiding content, and nothing lets a user reach it.
  // The viewport is `overflow: auto` - it may hold more than it shows, which is
  // the point - so it is reported as a check that it IS the scroller, not as
  // a clip.
  const clippingReport = (page: import("@playwright/test").Page) =>
    page.evaluate(() => {
      const isClipping = (el: Element) => {
        const { overflowY } = window.getComputedStyle(el);
        return overflowY === "hidden" || overflowY === "clip";
      };
      const hiddenOverflow = (el: Element) =>
        isClipping(el) ? el.scrollHeight - el.clientHeight : 0;

      const cells = Array.from(
        document.querySelectorAll<HTMLElement>('[data-testid^="dashboard-widget-"]')
      ).filter(el => el.dataset.testid !== "dashboard-widget-viewport");

      if (cells.length === 0) {
        throw new Error("no dashboard widget cells found");
      }

      // How far a box-shadow paints past its element on each side, from the
      // computed value (`<color> <x> <y> <blur> <spread>, ...`), so the check
      // follows whatever elevation the design system actually renders.
      const shadowReach = (el: Element) => {
        const reach = { top: 0, right: 0, bottom: 0, left: 0 };
        const { boxShadow } = window.getComputedStyle(el);
        if (!boxShadow || boxShadow === "none") {
          return reach;
        }
        for (const layer of boxShadow.split(/,(?![^(]*\))/)) {
          if (layer.includes("inset")) {
            continue;
          }
          const [x = 0, y = 0, blur = 0, spread = 0] = (
            layer.replace(/rgba?\([^)]*\)/g, "").match(/-?[\d.]+px/g) || []
          ).map(parseFloat);
          const size = blur + spread;
          reach.top = Math.max(reach.top, size - y);
          reach.bottom = Math.max(reach.bottom, size + y);
          reach.left = Math.max(reach.left, size - x);
          reach.right = Math.max(reach.right, size + x);
        }
        return reach;
      };

      return cells.map(cell => {
        const viewport = cell.querySelector<HTMLElement>(
          '[data-testid="dashboard-widget-viewport"]'
        );
        if (!viewport) {
          throw new Error(`${cell.dataset.testid} has no widget viewport`);
        }

        const cellRect = cell.getBoundingClientRect();
        const cellStyle = window.getComputedStyle(cell);
        const viewportRect = viewport.getBoundingClientRect();

        // The shadow a widget root paints that the scrolling viewport cuts
        // off, per side: its reach minus the room between the root and the
        // viewport's scrollable box (the bottom is measured to the end of the
        // scrolled content, since a root taller than the viewport scrolls).
        const shadowClipped = Math.max(
          0,
          // Only in-flow roots: a widget's closed MUI Modal/Backdrop sibling is
          // `position: fixed` and not a card, so it is no part of this layout.
          ...Array.from(viewport.children).map(child => {
            if (["fixed", "absolute"].includes(window.getComputedStyle(child).position)) {
              return 0;
            }
            const reach = shadowReach(child);
            if (!reach.top && !reach.right && !reach.bottom && !reach.left) {
              return 0;
            }
            const rect = child.getBoundingClientRect();
            const contentTop = viewportRect.top + viewport.clientTop - viewport.scrollTop;
            const room = {
              top: rect.top - contentTop,
              left: rect.left - (viewportRect.left + viewport.clientLeft),
              right:
                viewportRect.left +
                viewport.clientLeft +
                viewport.clientWidth -
                rect.right,
              bottom: contentTop + viewport.scrollHeight - rect.bottom
            };
            return Math.max(
              reach.top - room.top,
              reach.right - room.right,
              reach.bottom - room.bottom,
              reach.left - room.left
            );
          })
        );

        // The viewport's grow rule reaches EVERY in-flow child, so a widget
        // that renders a second in-flow root shares the cell with it: a card
        // beside one empty wrapper is laid out at about half the cell, and
        // nothing above notices, because a short card clips nothing. Out-of-flow
        // siblings (a closed Backdrop, a drawer's swipe area) take no part in
        // flex sizing and are not counted.
        const inFlowRoots = Array.from(viewport.children).filter(child => {
          const { display, position } = window.getComputedStyle(child);
          return display !== "none" && !["fixed", "absolute"].includes(position);
        });
        const viewportStyle = window.getComputedStyle(viewport);
        const viewportContentHeight =
          viewport.clientHeight -
          parseFloat(viewportStyle.paddingTop) -
          parseFloat(viewportStyle.paddingBottom);

        return {
          shadowClipped,
          inFlowRootCount: inFlowRoots.length,
          // How far the widget root falls short of the room the viewport gives
          // it. A root may be TALLER (the viewport scrolls it), never shorter.
          rootShortOfViewport: Math.max(
            0,
            ...inFlowRoots.map(
              root => viewportContentHeight - root.getBoundingClientRect().height
            )
          ),
          widget: cell.dataset.testid,
          cellHiddenOverflow: hiddenOverflow(cell),
          rootHiddenOverflow: Math.max(
            0,
            ...Array.from(viewport.children).map(child => hiddenOverflow(child))
          ),
          viewportOverflowY: window.getComputedStyle(viewport).overflowY,
          // The viewport has to end inside the cell's padding box, or the edit
          // chrome row pushed it off the bottom (the shape of the old clip).
          viewportBottomPastCell:
            viewportRect.bottom - (cellRect.bottom - parseFloat(cellStyle.paddingBottom))
        };
      });
    });

  // How much of `target` is hidden by the clipping boxes between it and its
  // cell: the intersection of every ancestor, up to and including the cell,
  // whose overflow is not `visible`. A clipped target can be "scrolled to" and
  // still be cut in half; this measures what is actually shown, whatever
  // element does the clipping.
  const hiddenPartOf = (target: import("@playwright/test").Locator) =>
    target.evaluate(el => {
      const isCell = (node: HTMLElement) => {
        const testId = node.dataset.testid || "";
        return (
          testId.startsWith("dashboard-widget-") && testId !== "dashboard-widget-viewport"
        );
      };
      const rect = el.getBoundingClientRect();
      let top = -Infinity;
      let bottom = Infinity;
      for (let node = el.parentElement; node; node = node.parentElement) {
        if (window.getComputedStyle(node).overflowY !== "visible") {
          const clip = node.getBoundingClientRect();
          top = Math.max(top, clip.top);
          bottom = Math.min(bottom, clip.bottom);
        }
        if (isCell(node)) {
          break;
        }
      }
      return {
        topCut: Math.round(Math.max(0, top - rect.top)),
        bottomCut: Math.round(Math.max(0, rect.bottom - bottom))
      };
    });

  // Waits until no widget viewport and not the page is still scrolling: a
  // wheel turn is dispatched before the scroll it causes has landed.
  const scrollSettled = (page: import("@playwright/test").Page) =>
    page.evaluate(
      () =>
        new Promise<void>(resolve => {
          const position = () =>
            [
              window.scrollY,
              ...Array.from(
                document.querySelectorAll('[data-testid="dashboard-widget-viewport"]')
              ).map(viewport => viewport.scrollTop)
            ].join(",");
          let last = position();
          let stillFrames = 0;
          const tick = () => {
            const now = position();
            stillFrames = now === last ? stillFrames + 1 : 0;
            last = now;
            if (stillFrames >= 5) {
              resolve();
            } else {
              requestAnimationFrame(tick);
            }
          };
          requestAnimationFrame(tick);
        })
    );

  // Brings `target` into view the way a mouse user does: the pointer over its
  // cell's viewport, turning the wheel. Never programmatically -
  // `scrollIntoView` moves boxes no wheel can (an `overflow: hidden` card) and
  // reaches straight past anything painted over the widget that swallows the
  // wheel. Returns how much of `target` is still hidden once it is shown in
  // full or a turn no longer moves it.
  const reachByWheel = async (
    page: import("@playwright/test").Page,
    cell: import("@playwright/test").Locator,
    target: import("@playwright/test").Locator
  ) => {
    await cell.scrollIntoViewIfNeeded();
    const viewportBox = await cell.getByTestId("dashboard-widget-viewport").boundingBox();
    if (!viewportBox) {
      throw new Error("widget viewport is not rendered");
    }
    await page.mouse.move(
      viewportBox.x + viewportBox.width / 2,
      viewportBox.y + viewportBox.height / 2
    );
    let cut = await hiddenPartOf(target);
    for (let turn = 0; turn < 10 && (cut.topCut || cut.bottomCut); turn++) {
      const before = await target.boundingBox();
      await page.mouse.wheel(0, 120);
      await scrollSettled(page);
      cut = await hiddenPartOf(target);
      if ((await target.boundingBox())?.y === before?.y) {
        break;
      }
    }
    return cut;
  };

  // The controls in `targets` a pointer aimed at their centre does NOT land
  // on, each with what it hits instead. A box painted over a widget (a MUI
  // SwipeableDrawer's invisible `position: fixed` swipe area once stretched
  // across Getting Started's whole cell) leaves every control on screen and
  // measurably unclipped while swallowing each click and wheel turn.
  const pointerMisses = (targets: import("@playwright/test").Locator) =>
    targets.evaluateAll(controls => {
      if (controls.length === 0) {
        throw new Error("no controls to hit-test");
      }
      const describe = (el: Element) =>
        `${el.tagName.toLowerCase()}.${String(el.className).split(" ").join(".")}`;
      return controls.flatMap(control => {
        const rect = control.getBoundingClientRect();
        const hit = document.elementFromPoint(
          rect.left + rect.width / 2,
          rect.top + rect.height / 2
        );
        return hit && control.contains(hit)
          ? []
          : [`${describe(control)} is covered by ${hit ? describe(hit) : "nothing"}`];
      });
    });

  const assertNothingClipped = async (
    page: import("@playwright/test").Page,
    { isEditMode }: { isEditMode: boolean }
  ) => {
    // Wait for the two widgets the report names to have rendered their content.
    const gettingStarted = page.getByTestId("dashboard-widget-GETTING_STARTED");
    const helpCenter = page.getByTestId("dashboard-widget-HELP_CENTER");
    const startButton = gettingStarted.getByRole("button", { name: "Start" });
    const lastHelpLink = helpCenter.getByRole("link", { name: "Meet with Team Member" });
    await expect(startButton).toBeAttached();
    await expect(lastHelpLink).toBeAttached();
    // The document's full-page loading overlay (`#__next-loading-indicator`,
    // pages/_document.tsx) is hidden on the window `load` event, and
    // `openDashboard` only waits for `domcontentloaded`. Until it goes, it is
    // what every hit-test below lands on.
    await expect(page.locator("#__next-loading-indicator")).toBeHidden();

    const report = await clippingReport(page);
    for (const cell of report) {
      expect
        .soft(cell.cellHiddenOverflow, `${cell.widget}: cell clips`)
        .toBeLessThanOrEqual(1);
      expect
        .soft(cell.rootHiddenOverflow, `${cell.widget}: widget root clips`)
        .toBeLessThanOrEqual(1);
      expect
        .soft(cell.shadowClipped, `${cell.widget}: card elevation shadow clipped`)
        .toBeLessThanOrEqual(0.5);
      expect
        .soft(cell.viewportOverflowY, `${cell.widget}: viewport scrolls`)
        .toBe("auto");
      expect
        .soft(cell.inFlowRootCount, `${cell.widget}: one in-flow widget root`)
        .toBe(1);
      expect
        .soft(cell.rootShortOfViewport, `${cell.widget}: widget root fills its viewport`)
        .toBeLessThanOrEqual(1);
      expect
        .soft(cell.viewportBottomPastCell, `${cell.widget}: viewport ends past the cell`)
        .toBeLessThanOrEqual(1);
    }

    for (const [widgetKey, cell, target] of [
      ["GETTING_STARTED", gettingStarted, startButton],
      ["HELP_CENTER", helpCenter, lastHelpLink]
    ] as const) {
      const cut = await reachByWheel(page, cell, target);
      expect.soft(cut, `${widgetKey}: last control reachable in full`).toEqual({
        topCut: 0,
        bottomCut: 0
      });
      // In edit mode every button in the cell, so the delete and drag chrome
      // too - checked here, while the cell is still on screen.
      const controls = isEditMode ? cell.locator("button") : target;
      expect
        .soft(await pointerMisses(controls), `${widgetKey}: controls take a pointer`)
        .toEqual([]);
    }
  };

  for (const viewport of [
    { name: "beyond xl", width: 2200, height: 1300 },
    { name: "desktop", width: 1440, height: 900 },
    { name: "laptop", width: 1280, height: 800 }
  ]) {
    test(`in view mode and edit mode (${viewport.name})`, async ({ page }) => {
      await page.setViewportSize({ width: viewport.width, height: viewport.height });
      await openDashboard(page);
      await expect(page.locator(".react-grid-layout")).toBeVisible();

      await assertNothingClipped(page, { isEditMode: false });

      await actionButton(page, "Edit").click();
      await expect(actionButton(page, "Edit")).toHaveCount(0);
      await assertNothingClipped(page, { isEditMode: true });
    });
  }
});
