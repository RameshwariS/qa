/**
 * The invitation form's "Set as open signup invitation" control, at the surface
 * the admin uses it.
 *
 * That control writes `isDefault`, the marker an organization declares its OPEN
 * invitation with - the one `AcceptOpenOrgInvitation` resolves when an existing
 * account signs in on the tenant's custom domain. The column was absent from
 * the invitation INSERT/UPDATE column lists, so the tick was discarded on the
 * way to the row and the control configured nothing at all; the storage half of
 * that is pinned against a real Postgres in
 * `server/dao/invitations_open_marker_test.go` and the whole sign-in journey in
 * `server/dao/open_invitation_signin_journey_test.go`.
 *
 * This spec pins the two halves a browser can observe:
 *
 *   1. the control is on the form and its value reaches the wire as
 *      `isDefault: true`, so the write the server now persists is the write the
 *      admin actually made; and
 *   2. when the server REFUSES a marker change - the 403 that gate answers a
 *      caller without the manage-invitations key with, and the 404 a stale edit
 *      modal gets - the user is told why. Both bodies carry their sentence under
 *      `error`, while the modal read `data.message` only, so every refusal
 *      reached the user as the literal string "Unknown error".
 */

import { Keys } from "@meshery/schemas/permissions";
import { expect, test, type Page, type Request } from "@playwright/test";
import path from "node:path";
import {
  createAuthenticatedShellHandlers,
  createFallbackHandlers,
  createSharedShellHandlers,
  mockApi
} from "./helpers/network";

/**
 * Where the reviewer-facing screenshots land. Defaults inside `test-results/`
 * (gitignored, cleaned with the rest of the run); override with
 * `INVITATION_MARKER_EVIDENCE_DIR` to collect them somewhere durable.
 */
const EVIDENCE_DIR =
  process.env.INVITATION_MARKER_EVIDENCE_DIR ??
  path.resolve(__dirname, "..", "test-results", "invitation-marker-evidence");

const shot = (name: string) => path.join(EVIDENCE_DIR, `${name}.png`);

/**
 * The org fixture's domain has to be the host Playwright actually browses, or
 * the authenticated shell bounces to `/auth/switch-domain` before the page
 * renders. Derived rather than hardcoded so the spec survives a run on a free
 * port (see ui/e2e/README.md).
 */
const currentHost = new URL(process.env.PLAYWRIGHT_BASE_URL || "http://localhost:3000")
  .host;

const manageInvitationsKey = {
  id: Keys.IdentityAccessManagementManageInvitations.id,
  function: Keys.IdentityAccessManagementManageInvitations.function
};

const authenticatedUser = {
  id: "user-1",
  first_name: "Test",
  last_name: "User",
  email: "test@example.com",
  preferences: { selectedOrg: "org-1" }
};

const organization = { id: "org-1", name: "Test Organization", domain: currentHost };

/**
 * The invitation row, spelled the way the PROVIDER serves it - the v1beta3
 * construct, whose keys are camelCase only.
 *
 * This spec keeps its own handlers rather than `createInvitationsHandlers`
 * because it has to capture each PUT body and inject a refusal, neither of
 * which the shared helper offers.
 *
 * It also used to avoid that helper because it emitted every field twice
 * (`orgId` and `org_id`, `isDefault` and `is_default`, ...) "for specs that
 * read either spelling": the edit modal seeds its form from the row and the
 * schema sets `additionalProperties: false`, so each invented key failed RJSF
 * validation and the Update button silently did nothing - a fixture artifact
 * that read exactly like the product bug this spec is here to observe, and
 * that left `invitations.spec.ts` red. The helper now serves camelCase only,
 * so a fixture no longer has to route around it.
 */
const existingInvitation = {
  id: "invite-1",
  owner: "user-1",
  name: "Engineering Team Invite",
  description: "Open seats for backend engineers",
  emails: [],
  status: "enabled",
  orgId: "org-1",
  quota: 5,
  acceptedBy: [],
  roles: [],
  teams: [],
  isDefault: false,
  createdAt: "2026-01-01T00:00:00Z",
  updatedAt: "2026-01-01T00:00:00Z"
};

/** GET the list, PUT an update - the two calls this page makes. */
const invitationHandlers = [
  (request: Request) => {
    const { pathname } = new URL(request.url());
    if (request.method() === "GET" && pathname === "/api/organizations/invitations") {
      return {
        body: { data: [existingInvitation], total: 1 },
        status: 200,
        contentType: "application/json"
      };
    }
    if (
      request.method() === "PUT" &&
      pathname === `/api/organizations/invitations/${existingInvitation.id}`
    ) {
      const submitted = JSON.parse(request.postData() ?? "{}");
      return {
        body: { ...existingInvitation, ...submitted },
        status: 200,
        contentType: "application/json"
      };
    }
    return undefined;
  }
];

/**
 * Opens the invitations page with the invitation API mocked, optionally
 * forcing the PUT to fail. Returns the parsed bodies of every invitation PUT
 * the page issued, so a test asserts the wire rather than the component's
 * internal state.
 *
 * The refusal handler is registered BEFORE `createInvitationsHandlers`:
 * `mockApi` takes the first handler that answers, so a failure fixture placed
 * after the working set is silently shadowed.
 */
async function openInvitationsPage(
  page: Page,
  refusal?: { status: number; body: unknown }
): Promise<Array<Record<string, unknown>>> {
  const updates: Array<Record<string, unknown>> = [];

  const captureUpdates = (request: Request) => {
    if (request.method() !== "PUT") return;
    if (!new URL(request.url()).pathname.startsWith("/api/organizations/invitations"))
      return;
    const body = request.postData();
    if (body) {
      updates.push(JSON.parse(body));
    }
  };

  await mockApi(page, [
    request => {
      captureUpdates(request);
      if (!refusal) return undefined;
      if (request.method() !== "PUT") return undefined;
      if (!new URL(request.url()).pathname.startsWith("/api/organizations/invitations")) {
        return undefined;
      }
      return {
        body: refusal.body,
        status: refusal.status,
        contentType: "application/json"
      };
    },
    ...createSharedShellHandlers({
      user: authenticatedUser,
      organizations: [organization]
    }),
    ...createAuthenticatedShellHandlers({ orgId: "org-1", keys: [manageInvitationsKey] }),
    ...invitationHandlers,
    ...createFallbackHandlers()
  ]);

  await page.goto("/identity/invitations");
  return updates;
}

/**
 * The open-signup checkbox.
 *
 * Addressed by the sentence the admin actually reads. It used to be addressed
 * by its PROPERTY NAME, because the ui schema carried that sentence under
 * `ui:label`, which RJSF reads as a BOOLEAN ("render the label at all") rather
 * than as label text - so the string was merely truthy and the control the
 * whole open-signup feature hangs on rendered as a checkbox labelled
 * `isDefault`. `ui:title` now supplies the words (#6001), and this locator
 * moved with the repair, exactly as the note it replaces asked for.
 */
const openSignupCheckbox = (modal: ReturnType<Page["getByRole"]>) =>
  modal.getByRole("checkbox", { name: "Set as open signup invitation" });

async function openEditModal(page: Page) {
  const row = page.getByRole("row", { name: new RegExp(existingInvitation.name) });
  await expect(row).toBeVisible();
  await row.getByTitle("Edit Invitation").click();
  const modal = page.getByRole("dialog");
  await expect(modal.getByText("Edit Invitation")).toBeVisible();
  return modal;
}

test.describe("open signup invitation marker", () => {
  test("the admin's tick reaches the wire as isDefault", async ({ page }) => {
    const updates = await openInvitationsPage(page);
    const modal = await openEditModal(page);

    const marker = openSignupCheckbox(modal);
    await expect(
      marker,
      "the control that declares the org's open invitation"
    ).toBeVisible();
    await expect(marker).not.toBeChecked();
    await marker.check();
    await page.screenshot({ path: shot("open-signup-control-ticked"), fullPage: true });

    await modal.getByRole("button", { name: "Update Invitation" }).click();

    await expect.poll(() => updates.length).toBe(1);
    expect(
      updates[0].isDefault,
      "the value the server persists must be the one the admin ticked"
    ).toBe(true);
  });

  test("a refused marker change reports the server's reason, not 'Unknown error'", async ({
    page
  }) => {
    const refusal = "Not permitted to change the organization's open signup invitation";
    const updates = await openInvitationsPage(page, {
      status: 403,
      body: { error: refusal }
    });
    const modal = await openEditModal(page);

    await openSignupCheckbox(modal).check();
    await modal.getByRole("button", { name: "Update Invitation" }).click();

    await expect.poll(() => updates.length).toBe(1);
    await expect(page.getByText(refusal)).toBeVisible();
    await expect(
      page.getByText("Unknown error"),
      "the refusal carries its text under `error`, which the modal used to ignore"
    ).toHaveCount(0);
    await page.screenshot({ path: shot("marker-refusal-toast"), fullPage: true });
  });

  test("an invitation deleted under a stale edit modal reports the 404's text", async ({
    page
  }) => {
    const notFound = "invitation not found";
    const updates = await openInvitationsPage(page, {
      status: 404,
      body: { error: notFound }
    });
    const modal = await openEditModal(page);

    await modal.getByLabel(/^Description$/i).fill("edited from a stale modal");
    await modal.getByRole("button", { name: "Update Invitation" }).click();

    await expect.poll(() => updates.length).toBe(1);
    await expect(page.getByText(notFound)).toBeVisible();
    await expect(page.getByText("Unknown error")).toHaveCount(0);
    await page.screenshot({ path: shot("stale-modal-404-toast"), fullPage: true });
  });
});
